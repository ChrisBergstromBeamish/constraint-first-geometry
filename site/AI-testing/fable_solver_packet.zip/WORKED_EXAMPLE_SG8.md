# Worked example — the up-quark mass, run through the method

A full run of the constraint-first method on a real problem the framework attacked: the mass of the up
quark. It shows every step, including the **required 4-D comparison** and the **honest grade**. Reproduce
this pattern for your own problem.

## 1. State the target
The up-quark mass at the Z scale, m_u(M_Z). Measured comparator (sealed, used only at the end): 1.27 ± 0.43 MeV.

## 2. Locate it in the Shape (full precision, all three layers)
The flavor carrier is the internal factor K6 = SU(3)/T^2 of the frozen Shape. Its Weyl group is
W(SU(3)) ≅ S3, with |S3| = 6. The up-type mass ladder assigns each rung to an exterior power of the A2
chamber plane of K6 (this is the **Actors** layer of the Shape):

- top rung   a=0  ->  Λ^0  (scalar / anchor actor)
- charm rung a=1  ->  Λ^1  (one-step actor)
- up rung    a=2  ->  Λ^2  (the minimal oriented two-step actor)

So the up quark is the Λ^2 "orientation" actor on the 2-D A2 chamber plane.

## 3. Compute from the geometry (target-blind)
Λ^2 of a 2-D plane transforms under any Weyl element w by det(w); for the A2 Weyl group S3, det(w) = sgn(w).
So the up actor lives in the 1-D **sign representation** of S3, and its normalized one-chamber 4-D shadow has
amplitude 1/√|S3| = **1/√6**. This is fixed by the group order alone — computed before the measured mass is
opened (target-blind).

Mass rule (Scale layer: the top-sector normalization fixes the up-sector scale; κ = e^(−π√3) is the geometric
ladder step; the dimensionless 1/√6 adds no new scale):

    m_u = m_t · κ^2 · (C_u/C_t) = m_t · κ^2 · (1/√6)

With m_t(M_Z) = 168.9 GeV: m_t·κ^2 = 3.1717 MeV (the raw 13-D ladder value), and dividing by √6 gives

    m_u(M_Z) = 1.295 MeV.

## 4. Compare to measurement
1.295 vs 1.27 ± 0.43 MeV  ->  a **+0.058σ** pull. (The earlier "3.17 MeV, +4.4σ miss" came from comparing the
raw 13-D ladder value directly to the 4-D running mass — i.e. implicitly setting the 13-D→4-D transport
coefficient to 1. That was a wrong-ruler comparison.)

## 5. Granularity check (paid, finite)
Finite Weyl group |S3| = 6; integer ladder labels; a rank-1 alternating projector; no continuous per-family
exponent; no 0.40 factor reverse-engineered to hit the answer. Negative controls: a common sector-wide factor
cancels against the top anchor; shifting charm breaks the charm win; a continuous ~0.40 fit is rejected. So
the factor is rung-selective **by representation type, not by fitted value.**

## 6. Compare to existing 4-D math (required) — and why 4-D cannot do it
In the ordinary 4-D Standard Model the up-quark Yukawa (hence m_u) is a **free input**: flat 4-D field theory
contains no structure that fixes it — you measure it and insert it by hand. So **4-D physics cannot derive or
force m_u at all.** The Shape is load-bearing precisely here: the internal K6 = SU(3)/T^2 geometry supplies a
finite Weyl-chamber combinatorics and an exterior-power actor ladder that flat 4-D does not contain, and it is
that combinatorics (Λ^2 -> sign rep -> 1/√6) that fixes the up rung relative to the top. Drop the internal
geometry and the number is unconstrained again. **This is the exact missing ingredient in 4-D: no internal
representation-theory to pin a family coefficient.**

## 7. Honest grade
- **Endpoint: DISSOLVED-as-wrong-ruler-comparison + DERIVED-GIVEN the frozen Shape's actor layer** (the
  assignment "up rung a=2 = Λ^2 orientation actor"). The 1/√6 math is target-blind; the physical assignment
  is a layer of the frozen Shape, now written as an explicit spin^c Dirac operator with the exact up-sector
  bundle. Not from-nothing, not from the bare manifold alone — derived *given* the frozen Shape, the same
  load-bearing basis every gate rests on.
- **Residual (shown, not hidden):** m_u(M_Z) = 1.295 MeV is a sharp prediction that stays falsifiable against
  future precision measurement.
- **What it is NOT:** the measured up mass reclassified as an anchor; verified physics.

## The shape of a good answer
Reproduce this pattern: name the target -> find the exact geometric feature that carries it (full precision)
-> compute target-blind -> show what 4-D lacks -> grade honestly with the residual named. If any step cannot
be done, say which one and why.
