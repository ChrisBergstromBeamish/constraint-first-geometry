# HOW TO USE THIS — solving your own problems with the Fable constraint-first framework

This packet lets you hand a hard physics problem to a capable AI and have it attempt a solution using the
Fable method: one frozen 13-dimensional geometry, a handful of measured anchors, and an honest grading
discipline. It contains the three deep roots (Shape, Scale, Granularity), the anchors, the closure taxonomy,
a worked example, and this instruction file. Give the whole packet to the AI along with your problem.

---

## 0. Honest status — read this first

Fable is a **candidate framework offered for review, not verified physics.** By its own count no gate is
"physics-closed"; there is no experimental confirmation and no independent peer review. Use this as a
disciplined way to *attack* a problem and generate structured, checkable hypotheses — never as established
truth. Every result you get out **must be graded honestly** (section 6). If the method cannot reduce your
problem to the geometry, the correct answer is to say so and name what is missing — that is a valid outcome.

---

## 1. The one instruction that matters most

**Use FULL PRECISION for Shape, Scale, and Granularity.**

The single most common way to get a wrong or misleading answer from this framework is to feed it a
truncated, rounded, or geometry-only version of the object. The Shape is the *full three-layer object at full
precision on the named branch*; the Scale is the absolute anchor M_Pl at full precision; the Granularity is
the exact finite cost discipline. Round any of them, or keep only the bare manifold, and a computation can
fail — or appear to succeed — **for that reason alone, with nothing right or wrong in the physics.**

Tell the AI explicitly: *"Use full precision for Shape, Scale, and Granularity; do not truncate the geometry
to just its manifold."*

---

## 2. The three deep roots (load these and use them)

1. **Shape** — the frozen 13-D object: 4-D spacetime × a small, stiff internal geometry (the flag manifold
   K6 = SU(3)/U(1)^2, together with S^2 and S^1_Y/Z2). It is filed in **three mathematically distinct
   layers** — a **Stage** (the carrier, category product ×), a **Rulebook** (the admissible transitions,
   direct sum ⊕), and a set of **Actors** (the operators/bundles, tensor ⊗). **All three layers are
   load-bearing.** See `The_Shape_13D.txt`.
2. **Scale** — the absolute-magnitude discipline: a formula is *not* a magnitude. Every dimensionful number
   must trace to an anchor (M_Pl), a scheme object, a generated scale, or an explicit dissolution. See
   `The_Scale.txt`.
3. **Granularity** — the finite-cost discipline: no unpaid labels, no hidden infinite precision, a **uniform
   positive cost floor** (Delta_0 > 0, with h-bar its measured size); finite candidate classes only. See
   `The_Granularity.txt`.

The measured anchors the framework consumes (and nothing more) are in `The_Anchors.txt`.

---

## 3. Why the Shape is load-bearing — and what it buys you

Everything the framework computes, it computes **from the frozen Shape object.** The internal geometry
supplies structure that flat 4-D field theory does not have: a finite Weyl-chamber combinatorics, exterior-
power "actor" ladders, topological indices, forced representation types, and quotient/boundary data. That is
why quantities that are *free parameters* in the ordinary 4-D Standard Model — the number of families, the
mixing angles, the mass-ladder pattern — can come out **forced** here: they are read off the geometry rather
than fitted.

So the first question for any problem is: **which feature of the frozen Shape (which layer, which operator,
which quotient) carries the quantity you want?** If nothing in the Shape carries it, the framework has no
special purchase on it, and you should say so.

---

## 4. The method (constraint-first) — apply to any problem

1. **State the target** precisely: a dimensionless ratio, a magnitude, a count, or a bound.
2. **Locate it in the Shape** — name the exact layer / operator / quotient that carries it. Full precision.
3. **Trace the Scale** — if the target is dimensionful, name the anchor / scheme / cross-scale bridge;
   otherwise keep it a dimensionless ratio (which is where the framework is strongest).
4. **Pay the Granularity** — every distinction, label, and candidate must be finitely specified and paid; no
   continuous fudge factor, no unpaid family label, no fractional exponent slipped in to hit a number.
5. **Compute** — read the result off the frozen geometry.
6. **Compare to 4-D** — required; see section 5.
7. **Grade the result honestly** — required; see section 6.

---

## 5. Always compare to existing 4-D math (required for every solution)

For every attempted solution, the AI must explicitly:

- **Show how the Shape is load-bearing** — which geometric feature supplies the answer, and what breaks if
  you drop it.
- **Attempt the same problem in ordinary 4-D** (Standard Model + General Relativity as usual).
- If 4-D can reproduce it, **say so** — then the Shape gave *economy*, not *necessity*.
- **If 4-D cannot solve it, state clearly WHY**, naming the exact missing ingredient — e.g. "in 4-D this
  quantity is a free input with no structure to fix it," or "it requires an internal topology/representation
  the flat theory does not contain." Do not hand-wave; name what 4-D lacks.

This comparison is the honest test of whether the Shape is doing real work or just re-describing a fit.

---

## 6. Grade every result honestly (the discipline that makes this worth using)

Put every result in exactly one terminal state, and **never round up**:

- **DERIVED** — computed from the frozen geometry, target-blind (the answer was fixed before the measured
  value was looked at).
- **DERIVED-GIVEN-anchor / -grammar** — follows once a named measured anchor, or a named layer of the frozen
  Shape, is accepted. *Anchored is not derived-from-nothing.*
- **REDUCED-TO-AXIOM** — rests on one named, stated posit.
- **DISSOLVED** — the question was ill-posed (e.g. a wrong-ruler comparison, or an assumed distinction the
  geometry does not support).
- **OPEN** — not solved; name exactly the missing object or the falsifier.

Non-negotiable rules: **anchored ≠ derived · selected ≠ forced · dissolved ≠ solved · a formula ≠ a
magnitude.** Never compare a "prediction" to the very measured value that was used to fix it and call it a
success. Show residuals plainly; never fold a residual into a hedge, and never fold it away into an
overclaim. See `The_Closure_system.txt`.

---

## 7. How to pose your problem to an AI (copy/paste prompt)

> Attempt the following problem using the Fable constraint-first method, from the packet I've given you.
> Use FULL PRECISION for Shape, Scale, and Granularity — do not truncate the geometry to its bare manifold.
> (1) State the target precisely. (2) Locate it in the frozen Shape and name the exact layer/operator/quotient
> that carries it. (3) Trace the Scale (name the anchor if it is dimensionful). (4) Pay the Granularity (no
> continuous fudge factor, no unpaid label). (5) Compute the result from the geometry. (6) Show explicitly how
> the Shape is load-bearing, then attempt the same problem in ordinary 4-D physics; if 4-D cannot solve it,
> state exactly why and name what 4-D lacks. (7) Grade the result with the closure taxonomy and name every
> residual honestly. If you cannot reduce it to the geometry, say so and name the missing object.
>
> The problem is: [PASTE YOUR PROBLEM HERE]

See `WORKED_EXAMPLE_SG8.md` for a full run of this method on a real problem (the up-quark mass).

---

## 8. What NOT to do

- Do **not** round or truncate the geometry, or keep only the bare manifold.
- Do **not** add a continuous coefficient or unpaid label to land on a target number.
- Do **not** call something "derived" when it is anchored, selected, or dissolved.
- Do **not** compare a derived quantity to the measured value that fixed it and call that a success.
- Do **not** present any result as verified physics. State the honest terminal, with its residual.
