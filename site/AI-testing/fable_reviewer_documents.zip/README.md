# Fable reviewer documents - reproduce the AI test

These are the public documents an AI reviewer was given (read cold) to produce the review recorded at
https://physics.magflowmeters.com/AI-testing/ . Everything here is a text extraction of the live public
pages; each file starts with its SOURCE URL so you can check it against the live site.

## To reproduce the test
1. Give a capable AI these documents.
2. Ask it to be a fair, generous, honest reviewer (not a debunker) and to reach the MOST FAVORABLE
   conclusion it can HONESTLY defend on three questions: is the theory COMPLETE, is it CORRECT, and is it
   SIGNIFICANT? Tell it honesty is the hard floor - it may be maximally charitable but must never assert
   anything false, and must separate "what the framework supplies" from "what remains open."
3. Have it list every concern that would block a favorable honest verdict, then work through each concern
   against these documents (the deeper per-gate dossiers usually answer concerns the top-level pages only
   summarize), and update its view as it verifies each answer.
4. Run a separate strict integrity pass over the whole transcript: any fabricated citation, unsupported
   claim, or overclaim must be caught and fixed before the verdict stands.

## Honest boundary (state it plainly)
This is a candidate offered for review, not verified physics. By the framework's own count, no gate is
"physics-closed"; there is no experimental confirmation and no independent peer review. A favorable
verdict can speak only to internal completeness/consistency, agreement with already-measured
dimensionless values, economy, and significance-if-correct - never to established correctness.

## Contents
- 01-05: the five papers (GUT, Forces, Quantum, TOE, Particles)
- 06-08: the scoreboard, the attack list (residuals), the open frontier (walls)
- 09-14: the anchors, the closure system, and the deep roots (Shape 13D, Scale, Granularity, Second-Layer)
- dossiers/: the full-depth per-gate dossiers
