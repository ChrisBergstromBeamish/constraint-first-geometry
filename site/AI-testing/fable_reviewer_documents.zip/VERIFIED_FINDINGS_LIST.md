# MASTER LIST — all verified findings (110 entries)

Assembled from the eight verified category files. Within each category, entries are ordered by human-persuasive force: concrete number + simple sentence + easy to verify first, abstract/method claims last. Entry format preserved exactly.

## TOP 10 overall

1. The universe's timeline computed twice — 44 checkpoints, zero disagreements
2. Electron, muon, and tau masses with zero lepton inputs
3. Two measured numbers in, nineteen-plus flavor numbers out
4. Exactly three families of matter — a topological integer computed two independent ways
5. Matter–radiation equality nailed to 0.6%
6. 64 out of 64 NASA-grade relativity benchmarks pass — and the calculators refuse to lie at the edges
7. The strong-CP puzzle: exactly zero, with no axion, no new particle, no tuning
8. Why quantum odds are amplitude SQUARED — the exponent 2 is pinned, and experiment already checked
9. A 113-orders-of-magnitude miss, kept on the books on purpose
10. The three forces are the built-in symmetries of one 13-dimensional shape — exactly, with none left over

---

## BLIND-PREDICTION

### The universe's timeline computed twice — 44 checkpoints, zero disagreements
PLAIN: Rebuilding the entire history of the universe from one idea — when a distinction first becomes affordable to record — reproduces the standard cosmological timeline from 20 microseconds to 13.8 billion years: of 44 checkpoints, 30 agree, 0 disagree, 14 remain open (open for all of cosmology too).
NUMBER: 44 checkpoints: 30 agree / 0 disagree / 14 indeterminate.
QUOTE: "Across 44 checkpoints there are zero disagreements ... from the first ~20 microseconds through to today's age of 13.8 billion years"
SOURCE: https://physics.magflowmeters.com/early-universe/tests/; https://physics.magflowmeters.com/early-universe/; https://physics.magflowmeters.com/
STATUS: the corpus's own framing: "nothing in this section is a confirmed prediction in the reserved sense" — two independent methods, zero disagreements; each row labeled Agrees/Indeterminate.

### Matter–radiation equality nailed to 0.6%
PLAIN: Asking "when does a density difference first survive long enough to be recorded?" independently dates the moment matter took over from radiation — within 0.6% of the Planck satellite's fitted value.
NUMBER: z_eq ≈ 3422 (framework) vs 3402 ± 26 (Planck) — 0.6%.
QUOTE: "z_eq ≈ 3422 (framework) vs 3402 ± 26 (Planck) — match to 0.6%"
SOURCE: https://physics.magflowmeters.com/early-universe/tests/
STATUS: Agrees (corpus label).

### The neutrino count 3.044 from counting affordable records
PLAIN: Counting what fraction of the radiation budget free-streaming neutrinos could buy reproduces the oddly precise effective neutrino number 3.044 — the same non-integer the textbook entropy bookkeeping gives, and the one Planck measures.
NUMBER: N_eff = 3.044 (both); measured 2.99 ± 0.17.
QUOTE: "Costing that fractional record share of the total radiation budget independently gives the same ≈3.04 'share count,' rather than the naive integer 3."
SOURCE: https://physics.magflowmeters.com/early-universe/tests/
STATUS: Agrees (corpus label).

### The first nuclei at 3 minutes, from erasure-vs-formation bookkeeping
PLAIN: Demanding that a deuterium nucleus survive being erased faster than it forms reproduces the famous "first three minutes" — the same 180-second breakout condition nuclear physics derives — with the predicted element abundances matching observation to under one sigma.
NUMBER: t ≈ 180 s; D/H and ⁴He match to ~0.2–0.7σ.
QUOTE: "requiring erasure-rate ≲ formation-rate reduces to the same balance ... so the record-affordability window opens at the same T ≈ 0.08 MeV, t ≈ 180 s"
SOURCE: https://physics.magflowmeters.com/early-universe/tests/
STATUS: Agrees (corpus label).

### The CMB really is a permanent snapshot — with a computed 130× safety margin
PLAIN: The record-affordability test says the universe's baby picture locked in classically at 380,000 years because records were being pinned down 130 times faster than expansion could stretch them away — the same margin plasma physics computes.
NUMBER: Γ/H ≈ 130 at last scattering; z* = 1089.92.
QUOTE: "Records lock in classically (decoherence rate ≈130× the expansion rate at last scattering) — the CMB really is a permanent snapshot."
SOURCE: https://physics.magflowmeters.com/early-universe/tests/
STATUS: Agrees (corpus label).

### The magnetic-monopole problem erased by 60 orders of magnitude — twice
PLAIN: Grand-unification theory overproduces magnetic monopoles by 17 orders of magnitude, and both the standard dilution calculation and the record-affordability calculation independently crush the relic abundance to the same fantastically small number — matching the fact that no monopole has ever been detected.
NUMBER: Ω_M h² ≈ 2×10⁻⁶¹ (both methods).
QUOTE: "the scar's abundance falls to the same Ω_M h² ≈ 2×10⁻⁶¹ — unaffordable to record, hence unseen"
SOURCE: https://physics.magflowmeters.com/early-universe/tests/
STATUS: Agrees (corpus label).

### The two methods share no machinery — so the agreement can't be circular
PLAIN: The record-affordability clock and the hot-Big-Bang equations have no common equations, calibration, or free parameters, so when both land on the same date for a cosmic event the match cannot be one method feeding the other — and a single genuine disagreement would count against the framework.
NUMBER: 0 shared parameters; 0 disagreements in 44.
QUOTE: "The granularity method and standard cosmology share no machinery — no common equations, no common calibration, no shared free parameters ... A single genuine disagreement would count against it — the test can fail."
SOURCE: https://physics.magflowmeters.com/early-universe/
STATUS: stated method discipline: "compute our number first, then compare."

### Black-hole entropy reproduced to 0.0028% under a freeze-before-compare rule
PLAIN: With every cut, measure, and normalization frozen before the famous Bekenstein–Hawking answer was consulted, the 13-D geometry reproduced the black-hole entropy law to about 3 parts in 100,000 — and the mysterious factor 1/4 falls out as a rigid ratio of two geometric constants by a route that deliberately refuses the field's standard shortcut.
NUMBER: S = A/4G reproduced to 0.0028% relative error; 1/4 = (4π)/(16πG)·G.
QUOTE: "the theory reproduces S=A_H/4G to 0.0028% relative error, obtained under a freeze-before-compare discipline (the admissibility firewall forbids fixing any cut, measure, or normalization after the comparison target is known)"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/gap13.html; TOE_FINAL_merged part 2/4
STATUS: explicitly tagged measured-diagnostic (inherited consistency check), NOT an ab-initio derivation; gate CERTIFIED-IRREDUCIBLE · RESOLVED +0; no microstate count claimed.

### The CMB's tilt falls inside the framework's projected band
PLAIN: The framework's own inflaton candidate — a breathing-mode of the internal geometry rolling down an exponential plateau — projects the tilt of the primordial ripples into a band four digits wide, and the satellite-measured value sits inside it.
NUMBER: projected n_s ∈ [0.9643, 0.9679]; Planck measures n_s = 0.9649 ± 0.0042.
QUOTE: "Our candidate inflaton (the σ breathing-mode of the internal geometry) rolls down an exponential-plateau potential ... projects n_s ∈ [0.9643, 0.9679]"
SOURCE: https://physics.magflowmeters.com/early-universe/tests/; https://physics.magflowmeters.com/gates/dossiers/gap08.html; https://physics.magflowmeters.com/gates/ (Gap-08)
STATUS: the corpus's own words: "a confirmed fit, not yet a locked prediction" — and the gap08 dossier grades the n_s agreement as a weak, non-discriminating consistency check generic to plateau models.

### A frozen coin-flip on the neutrino octant that DUNE and JUNO will call
PLAIN: The atmospheric neutrino mixing angle is currently ambiguous between two experimentally allowed values, and the framework's frozen prediction sits on one specific side — 0.04σ from the lower-octant solution and 4.6σ from the upper — so upcoming experiments settle it independently of anything computed here.
NUMBER: sin²θ₂₃ = 0.4493 ± 0.0005 (lower octant, pull 0.04σ; 4.60σ off the upper octant).
QUOTE: "\(\sin^2\theta_{23}\) (upper octant) ... \(4.60\) Diagnostic — DUNE/JUNO is the falsifier for octant"
SOURCE: Fable_GUT_merged part 27; https://physics.magflowmeters.com/gates/dossiers/sg8.html
STATUS: Certificate-complete (lower octant); upper-octant comparison a Diagnostic-only live falsifier.

### Dark energy needs no derivation — the model requires no single-point Big Bang
PLAIN: The old obligation to derive the dark-energy value dissolves: this framework's early-universe model requires no finite point mass or zero-volume singularity at the Big Bang — the Big Bang is where recording first becomes affordable, not a point of infinite density — so there is nothing for Λ to be derived from, and no requirement to. Λ's value stays one of the five honestly measured inputs, never claimed as a prediction, and the frozen geometry produces no internal dark-energy value, so nothing could have been reverse-engineered to fit. That the same no-singular-origin model whose early-universe timeline holds is what removes the derivation demand is further evidence that picture is right.
NUMBER: Λ ≈ (2.3 meV)⁴ ≈ 10⁻¹²² M_Pl⁴ — the fifth measured input, consumed as an observed cosmological anchor (supernova distances, CMB, large-scale structure), never predicted. Lovelock's theorem forces a Λ slot to exist in any 4D theory of gravity; this frozen compactification puts nothing in it, so there is no internal value to reverse-fit.
QUOTE: "Lovelock says a Λ slot exists in any admissible 4D gravity, Shape says this particular compactification does not fill it" and "the frozen object simply does not populate the Lovelock-admissible slot with anything."
SOURCE: https://physics.magflowmeters.com/gates/dossiers/gap05-value.html and deeproot-granularity.html; https://physics.magflowmeters.com/gates/ (Gap-05)
STATUS: MEASURED-ANCHOR · RESOLVED +0 — the value is honestly measured, never predicted; the demand to derive it dissolves as a wrong target (no single-point origin required).

### The theory tested its deepest hope on the hardest number in physics — and published the failure at full strength
PLAIN: On the cosmological constant — where a curve-fitter would have found a way to claim a win — the framework computed its own best cancellation mechanism, watched it fail at every order, proved by a clean group-theory argument why it had to fail, and published both certificates, never comparing to the observed value anywhere.
NUMBER: cancellation ratio 0.58 at k=0 and 1.000 at k=1–8 (a real cancellation would give 0); the ~122-order burden left standing.
QUOTE: "the exact-weight graded supertrace RAN and CLOSED as honest FAIL — no structural cancellation at any coefficient order ... the chamber route to Λ is closed, Weinberg stands"
SOURCE: Fable_Quantum_merged part 1/13; TOE_FINAL_merged parts 1–2; https://physics.magflowmeters.com/gates/dossiers/gap05-stability.html; https://physics.magflowmeters.com/toe/
STATUS: computed honest-FAIL, banked; the stability obstruction itself is CERTIFIED-IRREDUCIBLE · RESOLVED +0; Λ stays Weinberg-open.

### The consistency check you can do on a napkin — and it does double duty
PLAIN: The theory's charge bookkeeping hangs on arithmetic anyone can verify in 30 seconds — 3·(1/6) − 1/2 = 0 — and shifting one hypercharge by a single lattice step breaks two independent things at once (the electron's charge comes out −5/6 AND the anomaly sum stops vanishing), so the assignment has no slack at all.
NUMBER: 3·(1/6) − 1/2 = 0; wrong step ⇒ electron Q = −5/6 and a nonzero anomaly sum, simultaneously.
QUOTE: "Two things fail at once: the charge table gives the electron \(Q = -5/6\), and the napkin witness breaks... The same number that fixes the charges fixes the quantum consistency: that double duty is why the hypercharge lattice has no slack"
SOURCE: Fable_Forces_merged parts 1, 3; Fable_GUT_merged part 1; https://physics.magflowmeters.com/forces/; TOE_FINAL_merged part 1/4
STATUS: live hand-checkable witness; the cancellation is "inherited, not arranged" — consistency, not sole-origin proof.

### The program publishes its own refutations, retractions, and downgrades
PLAIN: Four of its own optimistic claims were falsified by its own audit and published as refuted with reasons; two tempting numerical coincidences were checked and retired as "an O(1) coincidence is not evidence"; a promising matter-antimatter result was withdrawn the same day it was produced; the quantum-computer side logged seven-plus self-caught corrections including retiring its flashiest ratios; and the headline input-economy claim was cut from ~4× to an honest 1.8× when a self-audit found overcounting.
NUMBER: 4 self-refuted routes; 2 retired coincidences; same-day withdrawal (R = 1.0001, 2026-06-04); ≥7 engineering corrections; margin 18×→4×; economy ~4×→1.8× (≈13–14 charged reals vs ≈25).
QUOTE: "Doing the physics this round actively falsified these optimistic closures. Re-attempting them as written wastes effort; the honest residual (where one remains) is named." and "Not '4 inputs → 22 outputs.' That historical headline is known-overstated and explicitly retired here."
SOURCE: https://physics.magflowmeters.com/residuals/; https://physics.magflowmeters.com/gates/dossiers/gap02.html, sg1.html, deeproot-shape.html; Fable_Quantum_merged parts 12–13
STATUS: banked negatives and corrected accountings, displayed by the corpus as its own discipline record.

### The honesty ledger: every claim graded, every anchor named, nothing claimed from nothing
PLAIN: The theory is graded as 33 distinct claims with the anchors named on each — the gates page shows 26 resting on the existing floor and 7 costing exactly one named value-free assumption each, zero vague — and states plainly that no gate is "solved from nothing," while the front page keeps the residual tensions in plain view rather than folding them into the wins.
NUMBER: 33 gates: 26 at +0, 7 at +1 (one named axiom each), 0 open (gates page); the home page presents the same board as "30 resolved at a terminal endpoint, 1 certified standing falsifier, and 2 honestly open at the structural frontier."
QUOTE: "26 closed at +0... 7 closed at +1 (each at the price of one named, value-free axiom) · 0 open... No gate is 'solved from nothing.' Every result ultimately rests on a small set of measured numbers"
SOURCE: https://physics.magflowmeters.com/gates/; https://physics.magflowmeters.com/; https://physics.magflowmeters.com/walls/
STATUS: the corpus's own reconciled boards at different audit dates; "anchored ≠ closed, selected is not forced, dissolved is not solved" — its own words.

### The whole framework leans on five "just-is" numbers — and says any theory's floor is at least one
PLAIN: Everything consumed from experiment at the anchor level is five numbers (Planck mass, gauge couplings, top coupling, one mixing element, dark-energy density) where standard particle physics leaves dozens of dials free — and the corpus publishes the fuller honest table too (~12–14 total measured inputs, each with a named consumer), stating as a rule that no framework anywhere derives its inputs from nothing.
NUMBER: 5 anchor inputs; ~12–14 total measured inputs with named consumers; input floor ≥ 1 for any theory.
QUOTE: "This value takes its place as the fifth of exactly five numbers the present framework accepts as 'just is'" and "no framework derives its measured inputs from nothing. The floor of measured inputs is never zero — not here, not anywhere."
SOURCE: https://physics.magflowmeters.com/gates/dossiers/gap05-value.html; https://physics.magflowmeters.com/anchors/
STATUS: anchors, not derived outputs; the anchors table is offered as accounting — "It closes nothing ... It derives nothing."

### The weakest link is printed on the cover, not buried
PLAIN: The quantum paper grades itself by the strictest possible rule — the whole work is only as strong as the weakest of its seventeen gates — prints that grade (AUDIT) on the front page, machine-enforces that no sentence claims more, and deliberately left its single most tempting row (strong CP) open rather than "completing" it.
NUMBER: Σ = min over 17 gates = AUDIT; 8 gates honestly held open.
QUOTE: "seventeen gates, each read in two tenses — what is closed, and what would close it — with the weakest link printed on the cover, not buried. The front page says the only number the min-rule permits: Σ = AUDIT"
SOURCE: Fable_Quantum_merged parts 1, 13
STATUS: self-declared aggregate, machine-checked.

### Freeze-before-compare: the anti-fitting rule is mechanical, not rhetorical — with a registered test built to come out negative
PLAIN: Every object the comparison pipeline reads is locked and hash-stamped before any measured number is loaded, any rule must be writable without ever looking at the answer it predicts, a published knob-audit table invites reviewers to find one unlisted parameter (finding one triggers an automatic downgrade), and a blind control was registered in advance to come out negative so a reader can check the grading discipline actually rejects things.
NUMBER: 18 frozen object classes; 10-row knob audit; registered blind-negative control PCM-12.
QUOTE: "Target-blindness — show the rule can be written without using the target observable. A rule that quotes the answer it is supposed to predict is target-selected, not forced." and "the closed core, with the registered blind-negative control PCM-12 built to come out negative so the discipline is checkable"
SOURCE: https://physics.magflowmeters.com/shape/; Fable_GUT_merged parts 4, 26; https://physics.magflowmeters.com/toe/
STATUS: binding rulebook; violation formally voids the certificate.

### One sentence predicts the theory's wins AND its own near-misses — and the one testable exception was tested
PLAIN: "Topology is rigid; magnitudes flow" cleanly predicts which numbers the geometry pins (integer counts, symmetries, dimensions) and which stay measured (masses, couplings) — and when the one continuous constant with a plausible derivation mechanism (the top coupling via a renormalization attractor) was computed target-blind, it came out wrong (1.34 vs 0.9665) and the framework reports the miss openly, keeping y_t a measured anchor.
NUMBER: attractor y_t ≈ 1.34 vs measured 0.9665 — negative result published.
QUOTE: "We ran the computation — and it does not reduce \(y_t\). At one loop, the infrared attractor sits near \(y_t \approx 1.34\), while the measured value is \(0.9665\)... (Checked target-blind, and independently reproduced.)"
SOURCE: https://physics.magflowmeters.com/process/what-geometry-forces.html
STATUS: honestly reported negative; the pattern is stated as falsifiable in both directions.

### The hierarchy "problem" is a ratio of two rulers, not a third mystery
PLAIN: The famous 17-orders-of-magnitude gap between the weak scale and the Planck scale stops being a mystery once both scales are honestly booked as measured inputs — the gap is just their quotient, and there was never a third object owing anyone a derivation.
NUMBER: H = v_EW/M_Pl ≈ 2×10⁻¹⁷ (from M_Pl = 1.2209×10¹⁹ GeV, v_EW ≈ 246 GeV).
QUOTE: "the hierarchy \(H \equiv v_{\rm EW}/M_{\rm Pl} \approx 2\times10^{-17}\) ... is arithmetic — the quotient of two numbers already charged to the ledger. It is emphatically not a third quantity owed a derivation of its own."
SOURCE: https://physics.magflowmeters.com/gates/dossiers/deeproot-scale.html; https://physics.magflowmeters.com/gates/ (DeepRoot-Scale)
STATUS: MEASURED-ANCHOR · RESOLVED +0; the electroweak scale's microphysical origin stays a named open hole.

### Why atoms are exactly neutral is an identity, not a coincidence
PLAIN: Because electromagnetism is forced to be the leftover of the weak sector rather than an independent force, the photon's charges are the weak sector's charges by construction — the perfect cancellation that makes atoms neutral (to one part in 10²¹) is inherited, not tuned.
NUMBER: Q = T₃ + Y reproduces every observed charge row; matter neutrality exact to ~10⁻²¹.
QUOTE: "atom neutrality would become a coincidence to be tuned rather than an identity to be inherited. The composite structure makes that failure unwritable: QED's charges are the weak sector's charges, by construction"
SOURCE: Fable_Forces_merged part 3/4; Fable_GUT_merged part 4
STATUS: interface claim, machine-checked (certificate Q04 PASS).

### Matter vs antimatter: a wall proven, not an excuse offered
PLAIN: Rather than tuning unobservable heavy-neutrino parameters to "explain" the matter excess (as the literature does), the framework proved by two independent exact calculations that the one missing number cannot be extracted from anything ever measured — and named the future measurement that would supply it.
NUMBER: two independent routes agree to residual ≤ 7.1×10⁻¹⁶ across six decades of the heavy scale; η_B ≈ 6.1×10⁻¹⁰ consumed as a measured input.
QUOTE: "proven un-derivable from the four anchors and un-measurable from the entire light-neutrino sector, by two independent, target-blind calculational routes that reach exact agreement"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/gap10-bg10.html
STATUS: CERTIFIED-IRREDUCIBLE · RESOLVED +0 — a proof of a wall; no η_B value claimed.

### Why a dark-energy term must exist at all is a theorem — three tangled questions cleanly split
PLAIN: What looks like one baffling dark-energy mystery splits into three questions with three different clean answers: a Λ-slot must exist (forced by Lovelock's 1971 classification theorem in 4D), its tiny size is a measurement, and the scary vacuum estimate never gravitates (dissolved) — the three are never conflated.
NUMBER: Λ = (2.3 meV)⁴ ≈ 10⁻¹²² M_Pl⁴, charged as a measured input.
QUOTE: "the existence of a cosmological-constant term is forced by a complete classification theorem (Lovelock, 1971) ... so 'why is there a \(\Lambda\) slot at all' is closed, even while 'why does \(\Lambda\) have the value it has' is not"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/deeproot-scale.html and lambda-catastrophe.html
STATUS: existence forced (known theorem) / value MEASURED / catastrophe dissolved — as stated per question.

### An absolute scale must exist — that part is a theorem; its value is read, not derived
PLAIN: The framework proves some absolute measurement ruler must exist (change units and any bare number changes with them, so only ratios or anchored values carry content), then honestly reads the ruler's value from experiment instead of pretending to derive it.
NUMBER: M_Pl = 1.2209×10¹⁹ GeV (measured anchor).
QUOTE: "That an absolute scale must exist is a theorem ... But the value of that anchor is read from experiment, never derived. ... Existence is proven; the numbers are measured; the two are never merged."
SOURCE: https://physics.magflowmeters.com/building-blocks/
STATUS: existence proven; value anchored to measurement.

### Every hard quantum-gravity consistency check funnels to one named problem
PLAIN: Rather than hand-waving its hardest quantum checks, the theory proves that its graviton sector, UV completion, short-distance structure, and causality requirements all reduce to one single shared mathematical fact — the Yang–Mills mass gap — naming exactly the one thing the program leans on instead of hiding many loose ends.
NUMBER: 4+ consistency gates reduced to 1 shared object.
QUOTE: "it proves that every one of its own consistency requirements reduces to that single shared object (Gap-02), and that the object's value enters as a measured anchor. That is an honest, closed terminal"
SOURCE: https://physics.magflowmeters.com/quantum/
STATUS: CERTIFIED-IRREDUCIBLE (the Yang–Mills problem itself is not claimed solved; its value enters as a measured anchor).

### The same two frozen numbers run particle physics AND the chip design
PLAIN: The integer 3 that counts the particle families and a spectral gap of 0.260 — both frozen in the geometry for physics reasons — turn up doing a second, completely unrelated job inside the quantum-computer design, with no feedback loop between the two projects.
NUMBER: Atiyah–Singer index = 3; spectral gap Δ ≈ 0.260.
QUOTE: "the same frozen geometric invariants — the Atiyah–Singer index equal to 3 (the same integer that counts three particle families) and a spectral gap Δ ≈ 0.260 — show up doing a second, unrelated job"
SOURCE: https://physics.magflowmeters.com/tests/quantum-computer.html
STATUS: structural invariants carried through both projects; the QC result itself is simulated/design-stage.

### Proton safety without banning what the Standard Model needs
PLAIN: The lazy fix — postulating a law that baryon number is conserved — would secretly outlaw processes the Standard Model itself requires (sphalerons); the geometric mechanism forbids proton decay while leaving those processes untouched.
NUMBER: sphalerons change B and L by ±3 each; a global U(1)_B symmetry is excluded for exactly this reason.
QUOTE: "A continuous global \(U(1)_B\) symmetry would forbid sphalerons. So global \(B\) symmetry is structurally incompatible with the SM."
SOURCE: Fable_GUT_merged part 23
STATUS: named constraint inside the proton-safety closure (Claimed certificate pass at operator level).

### One mechanical rule sorts every cosmic object the way physicists do case-by-case
PLAIN: A single four-part test — coupled, encoded, stabilized, retrievable — applied blindly to nine early-universe objects sorts every one exactly the way decades of case-by-case physics judgment does (CMB photons real, monopoles not, dark matter's identity open), with zero mismatches.
NUMBER: 9/9 objects, 0 mismatches.
QUOTE: "One is case-by-case textbook judgment, the other is a single mechanical rule applied blindly — they share no logic, yet they sort every object the same way."
SOURCE: https://physics.magflowmeters.com/early-universe/tests/
STATUS: Agrees (corpus label).

### The knowable universe is a window, not a wall — and both methods stop at the same Planck instant
PLAIN: Two structural consequences fall out for free: the knowable beginning and end are always the same distance in time from us (the observable universe widens symmetrically, no edge is ever hit), and dimensional analysis and record-cost bookkeeping — two unrelated arguments — both run out at the identical instant, 5.39×10⁻⁴⁴ seconds, where recordable history begins.
NUMBER: t_Pl ≈ 5.39×10⁻⁴⁴ s (both methods).
QUOTE: "the knowable beginning and the knowable end are always the same distance in time from us" and "Dimensional analysis and record-cost bookkeeping share no machinery, yet both stop at the identical wall — an honest shared limit, not a computed win."
SOURCE: https://physics.magflowmeters.com/early-universe/ and /early-universe/tests/
STATUS: derived structural consequence + an honestly-labeled shared limit ("not a computed win").

### "Forever" was never available: the eternal horizon retired, the real one kept
PLAIN: The textbook event horizon needs an infinite future to even be defined, but real black holes evaporate — so the framework keeps only the locally defined trapping horizon, which stays strictly one-way for the object's entire lifetime, effectively absolute for any observer in a 10-billion-year-old universe.
NUMBER: one-way for ~10⁶⁷ yr (stellar) to ~10¹⁰⁰ yr (supermassive) vs a universe ~10¹⁰ yr old.
QUOTE: "with a singularity-free interior there is, in Hawking's own 2014 phrase, 'no event horizon, only an apparent horizon.' The trapping horizon is not thereby made leaky — it is one-way for the entire \(10^{67}\)–\(10^{100}\)-year lifetime"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/blackhole-singularity.html
STATUS: part of the DISSOLVED-GIVEN-root closure; consistent with the GW150914 area-law confirmation.

### The information-escape turnover inside an evaporating black hole solves in closed form
PLAIN: Where the state of the art needs holography or two-dimensional toy models, this geometry's quantum-extremal-surface location solves explicitly and symbolically, and the information-recovery turnover comes out structural rather than assumed.
NUMBER: island location x⋆ = −r_h/2 + √(3Gc+9παr_h²)/(6√(πα)).
QUOTE: "the QES (quantum extremal surface) location itself solves explicitly and symbolically on the frozen 4D s-wave-reduced sector ... and the qualitative turnover survives without needing to postulate a finite-dimensional horizon Hilbert space by hand"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/gap13.html
STATUS: derived (qualitative turnover); the Page-time magnitude remains open and scheme-dependent — as it is for the whole field, per the corpus.

### The universe's smallest meaningful scale belongs to the strong force, not gravity
PLAIN: In this geometry the fundamental resolution scale is not the Planck length of gravity folklore — it is a pure color-force object about 194 Planck lengths across, a concrete, surprising read-off of where the shape actually bottoms out.
NUMBER: R₀/ℓ_Planck ~ 194 (a pure color/gauge object with zero gravitational input).
QUOTE: "the minimal-length scale here is a pure-color object (~194 Planck lengths)"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/uqf5c.html
STATUS: banked screening result; whether gravity owns its own intrinsic minimal scale is isolated and still open.

### No hidden free-rider particles: spectator sectors are ruled out by constraint alone
PLAIN: Extra disconnected particle sectors that couple to nothing — the free-riders that plague model-building elsewhere — are eliminated outright by the nonseparability constraint itself, which the corpus calls the strongest, rarest kind of result: forced by the constraints, not merely consistent with them.
NUMBER: —
QUOTE: "Unpaid spectator sectors and disconnected vectorlike additions to the observed spectrum are ruled out by the Nonseparability constraint itself, not by a modeling choice — the strongest, rarest kind of result, forced rather than merely consistent."
SOURCE: https://physics.magflowmeters.com/emergent-separability/
STATUS: resolved (with the three-generation count explicitly kept separate as observation-earned).

### The report card built the theory
PLAIN: The eight classic ways a grand unified theory dies (mirror particles, anomalies, proton decay, unprotected Higgs, arbitrary flavor...) were not used to grade a finished theory — the same failure list was the blueprint that eliminated candidate geometries in the first place, one standard applied in two tenses.
NUMBER: 10 required construction gates; every proper subset of the three layers provably fails at least one.
QUOTE: "Nothing was built and then graded; the grading rubric did the building."
SOURCE: Fable_GUT_merged parts 1–2 (quote in part 2, §1.3 "The Inversion")
STATUS: method claim with a four-point circularity defense (selection reads architecture, certificates read numbers; falsifiers stay live).

### The whole theory starts from a fact every physics student already knows
PLAIN: The seed of the entire framework is Gauss's law — the century-tested fact that a field outside a closed surface doesn't care how the source inside is arranged — read as a constraint the deep structure of space must reproduce exactly, which by itself eliminates whole classes of candidate geometries.
NUMBER: —
QUOTE: "a field measured outside a closed surface does not care how its source is arranged inside that surface. That is not a metaphor for the theory. It is the theory's actual starting constraint."
SOURCE: https://physics.magflowmeters.com/process/thought-experiment.html
STATUS: textbook fact plus a stated methodological choice; the page itself claims no derived number.
