# MASTER LIST — all verified findings (110 entries)

Assembled from the eight verified category files. Within each category, entries are ordered by human-persuasive force: concrete number + simple sentence + easy to verify first, abstract/method claims last. Entry format preserved exactly.

## TOP 10 overall

1. The universe's timeline computed twice — 44 checkpoints, zero disagreements
2. Electron, muon, and tau masses with zero lepton inputs
3. Two measured numbers in, nineteen-plus flavor numbers out
4. Exactly three families of matter — a topological integer computed two independent ways
5. Matter–radiation equality nailed to 0.6%
6. 64 out of 64 NASA-grade relativity benchmarks pass — and the calculators refuse to lie at the edges
7. The strong-CP puzzle: exactly zero, with no axion, no new particle, no tuning
8. Why quantum odds are amplitude SQUARED — the exponent 2 is pinned, and experiment already checked
9. A 113-orders-of-magnitude miss, kept on the books on purpose
10. The three forces are the built-in symmetries of one 13-dimensional shape — exactly, with none left over

---

## BLIND-PREDICTION

### The universe's timeline computed twice — 44 checkpoints, zero disagreements
PLAIN: Rebuilding the entire history of the universe from one idea — when a distinction first becomes affordable to record — reproduces the standard cosmological timeline from 20 microseconds to 13.8 billion years: of 44 checkpoints, 30 agree, 0 disagree, 14 remain open (open for all of cosmology too).
NUMBER: 44 checkpoints: 30 agree / 0 disagree / 14 indeterminate.
QUOTE: "Across 44 checkpoints there are zero disagreements ... from the first ~20 microseconds through to today's age of 13.8 billion years"
SOURCE: https://physics.magflowmeters.com/early-universe/tests/; https://physics.magflowmeters.com/early-universe/; https://physics.magflowmeters.com/
STATUS: the corpus's own framing: "nothing in this section is a confirmed prediction in the reserved sense" — two independent methods, zero disagreements; each row labeled Agrees/Indeterminate.

### Matter–radiation equality nailed to 0.6%
PLAIN: Asking "when does a density difference first survive long enough to be recorded?" independently dates the moment matter took over from radiation — within 0.6% of the Planck satellite's fitted value.
NUMBER: z_eq ≈ 3422 (framework) vs 3402 ± 26 (Planck) — 0.6%.
QUOTE: "z_eq ≈ 3422 (framework) vs 3402 ± 26 (Planck) — match to 0.6%"
SOURCE: https://physics.magflowmeters.com/early-universe/tests/
STATUS: Agrees (corpus label).

### The neutrino count 3.044 from counting affordable records
PLAIN: Counting what fraction of the radiation budget free-streaming neutrinos could buy reproduces the oddly precise effective neutrino number 3.044 — the same non-integer the textbook entropy bookkeeping gives, and the one Planck measures.
NUMBER: N_eff = 3.044 (both); measured 2.99 ± 0.17.
QUOTE: "Costing that fractional record share of the total radiation budget independently gives the same ≈3.04 'share count,' rather than the naive integer 3."
SOURCE: https://physics.magflowmeters.com/early-universe/tests/
STATUS: Agrees (corpus label).

### The first nuclei at 3 minutes, from erasure-vs-formation bookkeeping
PLAIN: Demanding that a deuterium nucleus survive being erased faster than it forms reproduces the famous "first three minutes" — the same 180-second breakout condition nuclear physics derives — with the predicted element abundances matching observation to under one sigma.
NUMBER: t ≈ 180 s; D/H and ⁴He match to ~0.2–0.7σ.
QUOTE: "requiring erasure-rate ≲ formation-rate reduces to the same balance ... so the record-affordability window opens at the same T ≈ 0.08 MeV, t ≈ 180 s"
SOURCE: https://physics.magflowmeters.com/early-universe/tests/
STATUS: Agrees (corpus label).

### The CMB really is a permanent snapshot — with a computed 130× safety margin
PLAIN: The record-affordability test says the universe's baby picture locked in classically at 380,000 years because records were being pinned down 130 times faster than expansion could stretch them away — the same margin plasma physics computes.
NUMBER: Γ/H ≈ 130 at last scattering; z* = 1089.92.
QUOTE: "Records lock in classically (decoherence rate ≈130× the expansion rate at last scattering) — the CMB really is a permanent snapshot."
SOURCE: https://physics.magflowmeters.com/early-universe/tests/
STATUS: Agrees (corpus label).

### The magnetic-monopole problem erased by 60 orders of magnitude — twice
PLAIN: Grand-unification theory overproduces magnetic monopoles by 17 orders of magnitude, and both the standard dilution calculation and the record-affordability calculation independently crush the relic abundance to the same fantastically small number — matching the fact that no monopole has ever been detected.
NUMBER: Ω_M h² ≈ 2×10⁻⁶¹ (both methods).
QUOTE: "the scar's abundance falls to the same Ω_M h² ≈ 2×10⁻⁶¹ — unaffordable to record, hence unseen"
SOURCE: https://physics.magflowmeters.com/early-universe/tests/
STATUS: Agrees (corpus label).

### The two methods share no machinery — so the agreement can't be circular
PLAIN: The record-affordability clock and the hot-Big-Bang equations have no common equations, calibration, or free parameters, so when both land on the same date for a cosmic event the match cannot be one method feeding the other — and a single genuine disagreement would count against the framework.
NUMBER: 0 shared parameters; 0 disagreements in 44.
QUOTE: "The granularity method and standard cosmology share no machinery — no common equations, no common calibration, no shared free parameters ... A single genuine disagreement would count against it — the test can fail."
SOURCE: https://physics.magflowmeters.com/early-universe/
STATUS: stated method discipline: "compute our number first, then compare."

### Black-hole entropy reproduced to 0.0028% under a freeze-before-compare rule
PLAIN: With every cut, measure, and normalization frozen before the famous Bekenstein–Hawking answer was consulted, the 13-D geometry reproduced the black-hole entropy law to about 3 parts in 100,000 — and the mysterious factor 1/4 falls out as a rigid ratio of two geometric constants by a route that deliberately refuses the field's standard shortcut.
NUMBER: S = A/4G reproduced to 0.0028% relative error; 1/4 = (4π)/(16πG)·G.
QUOTE: "the theory reproduces S=A_H/4G to 0.0028% relative error, obtained under a freeze-before-compare discipline (the admissibility firewall forbids fixing any cut, measure, or normalization after the comparison target is known)"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/gap13.html; TOE_FINAL_merged part 2/4
STATUS: explicitly tagged measured-diagnostic (inherited consistency check), NOT an ab-initio derivation; gate CERTIFIED-IRREDUCIBLE · RESOLVED +0; no microstate count claimed.

### The CMB's tilt falls inside the framework's projected band
PLAIN: The framework's own inflaton candidate — a breathing-mode of the internal geometry rolling down an exponential plateau — projects the tilt of the primordial ripples into a band four digits wide, and the satellite-measured value sits inside it.
NUMBER: projected n_s ∈ [0.9643, 0.9679]; Planck measures n_s = 0.9649 ± 0.0042.
QUOTE: "Our candidate inflaton (the σ breathing-mode of the internal geometry) rolls down an exponential-plateau potential ... projects n_s ∈ [0.9643, 0.9679]"
SOURCE: https://physics.magflowmeters.com/early-universe/tests/; https://physics.magflowmeters.com/gates/dossiers/gap08.html; https://physics.magflowmeters.com/gates/ (Gap-08)
STATUS: the corpus's own words: "a confirmed fit, not yet a locked prediction" — and the gap08 dossier grades the n_s agreement as a weak, non-discriminating consistency check generic to plateau models.

### A frozen coin-flip on the neutrino octant that DUNE and JUNO will call
PLAIN: The atmospheric neutrino mixing angle is currently ambiguous between two experimentally allowed values, and the framework's frozen prediction sits on one specific side — 0.04σ from the lower-octant solution and 4.6σ from the upper — so upcoming experiments settle it independently of anything computed here.
NUMBER: sin²θ₂₃ = 0.4493 ± 0.0005 (lower octant, pull 0.04σ; 4.60σ off the upper octant).
QUOTE: "\(\sin^2\theta_{23}\) (upper octant) ... \(4.60\) Diagnostic — DUNE/JUNO is the falsifier for octant"
SOURCE: Fable_GUT_merged part 27; https://physics.magflowmeters.com/gates/dossiers/sg8.html
STATUS: Certificate-complete (lower octant); upper-octant comparison a Diagnostic-only live falsifier.

### A live gravitational-wave prediction a satellite can kill by ~2030
PLAIN: The framework pre-registers a specific primordial gravitational-wave band — and if the LiteBIRD satellite measures outside it, the inflation mechanism is dead regardless of convention; inside it, the four candidate bands separate cleanly enough that the experiment even settles the theory's own normalization.
NUMBER: r ∈ [3.5, 36]×10⁻³ (union falsifier; operative branch [3.5, 10]×10⁻³); current bound r < 0.036; LiteBIRD ~2030.
QUOTE: "if LiteBIRD measures r outside [3.5, 36]×10⁻³, the σ-inflaton is falsified regardless of convention. Inside the union, the four r-bands separate at LiteBIRD resolution — the convention becomes an observable"
SOURCE: TOE_FINAL_merged part 2/4; https://physics.magflowmeters.com/gates/dossiers/gap08.html; https://physics.magflowmeters.com/early-universe/tests/
STATUS: live pre-registered falsifiable bet, not yet tested; "a band from four honest normalization choices, not yet a single forced number."

### A pre-registered pass/fail window for the matter–antimatter asymmetry
PLAIN: The framework has an armed, pre-registered window for the baryon asymmetry of the universe — a number it must hit or be falsified — while proving (by two independent exact calculations agreeing to one part in 10¹⁵) that the one missing input cannot be extracted from anything ever measured, and naming the future measurement that would supply it.
NUMBER: falsifier η_B ∈ [6.0, 6.2]×10⁻¹⁰ (at 3σ, armed but not yet run); two routes agree to residual ≤ 7.1×10⁻¹⁶ across six decades of the heavy scale.
QUOTE: "Falsifier: $\eta_B \in [6.0,6.2]\times10^{-10}$" and "proven un-derivable from the four anchors and un-measurable from the entire light-neutrino sector, by two independent, target-blind calculational routes"
SOURCE: https://physics.magflowmeters.com/walls/; https://physics.magflowmeters.com/gates/dossiers/gap10-bg10.html
STATUS: OPEN-ANCHORED falsifier armed (may only run after the four-fix program's upstream legs hold); the wall itself CERTIFIED-IRREDUCIBLE · RESOLVED +0 with η_B consumed as a measured anchor — no value claimed.

### The dark-matter claim ships with its own kill switch
PLAIN: The dark-matter candidate comes with a pre-registered forecast that direct-detection cross-sections sit ten-plus orders of magnitude below current experiments — so any positive detection signal in that band kills the minimal candidate outright, a built-in way to lose published in advance.
NUMBER: σ_SI ~ 10⁻⁵⁵–10⁻⁶⁰ cm² (35–40 orders of magnitude below current experimental reach).
QUOTE: "a pre-registered refute-only direct-detection falsifier stands ready to kill the minimal candidate on any positive signal in the \sigma_{\rm SI} \sim 10^{-55\text{–}60}\,\mathrm{cm}^2 band"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/gap11.html; https://physics.magflowmeters.com/walls/; Fable_Quantum_merged part 1/13
STATUS: live refute-only falsifier, not yet tested; the corpus notes a null result can never confirm it ("a band no null result can ever confirm").

### A standing offer to be killed by the lattice
PLAIN: Because the strong coupling and quark masses are outputs of the geometry rather than dials, any sub-percent disagreement with future lattice-QCD extractions falsifies the framework outright — a sharpness no theory with free parameters can offer.
NUMBER: sub-percent disagreement = falsification; FLAG 2024 currently consistent at the few-percent level.
QUOTE: "Any sub-percent disagreement between framework-predicted inputs and lattice-extracted ones (after running between scales) would falsify the framework."
SOURCE: Fable_Quantum_merged part 8/13
STATUS: named falsification anchor ("the sharpest near-term falsification anchor of UQF-11").

### No dark photon, no fifth force — a sweeping falsifiable "no"
PLAIN: Because the gauge forces are fixed by the shape rather than chosen, the framework predicts NO dark photon at any mass and no hidden light force — a hard negative prediction where a single confirmed detection anywhere would falsify the ledger.
NUMBER: dark-photon mixing ε = 0 at every mass.
QUOTE: "The framework predicts no dark photon at any mass. The bound is trivially satisfied (the framework is in the \"no hidden vector\" corner ... equivalent to \(\epsilon = 0\) for any \(m_{A'}\))."
SOURCE: Fable_Quantum_merged part 11/13
STATUS: the row closes at AUDIT-tier, "satisfied by inheritance from the absence of any hidden U(1) in the §4 ledger" — an inherited-ledger audit, not a certificate-tier closure.

### The open problems stay open — including a tension the framework refuses to fake-solve
PLAIN: The 14 unresolved checkpoints (dark matter's identity, the matter–antimatter asymmetry, the lithium-7 excess, the S8 tension) are the same questions all of cosmology has open, and the framework reproduces the standard calculation and reports each one open rather than claiming a win — evidence the 30 agreements aren't rounded up.
NUMBER: 14 of 44 indeterminate; lithium-7: predicted A(Li) ≈ 2.6–2.7 vs observed 2.1–2.2 (~3× gap, reported).
QUOTE: "we reproduce the standard calculation and report the tension honestly rather than papering over it"
SOURCE: https://physics.magflowmeters.com/early-universe/tests/
STATUS: Indeterminate rows, explicitly "open for everyone ... no rounding up."

## PRACTICAL-TEST

### 64 out of 64 NASA-grade relativity benchmarks pass — and the calculators refuse to lie at the edges
PLAIN: A public suite of deep-space relativity calculators built under the framework's discipline passes all 64 checks against textbook physics and real mission data — GPS clocks, the 1919 eclipse, Cassini, Pound–Rebka, NASA's 2023 deep-space laser link — including 8 dedicated adversarial checks that they fail visibly at impossible inputs instead of silently returning a plausible wrong number.
NUMBER: 64/64 checks pass (e.g. solar deflection 1.75119 arcsec vs 1.7505; GPS clock rate 45.66 vs 45.7 µs/day); 8/8 fail-closed tests pass.
QUOTE: "a single validation suite of 64 checks, run automatically before deployment... Total 64 64" and "the calculators do not silently return a plausible-looking wrong number at singular or unphysical inputs... they fail visibly instead"
SOURCE: https://physics.magflowmeters.com/tests/nasa-calculators.html
STATUS: pass, deployment gate PASS; explicitly "not mission-certified" and a correctness check on standard GR/optics, not a test of the new theory.

### All 442 catalogued particles accounted for, and parameter-free mass relations hold to under 1%
PLAIN: Every meson, baryon, antiparticle, resonance, and nucleus in the 2024 particle-data catalog is individually classified from the geometry's short alphabet plus standard confinement — a fail-closed machine audit reports zero inconsistencies — and the classic parameter-free mass relations check out (octet formula to 0.57%, Regge lines at R² = 0.9987).
NUMBER: 442 PDG-2024 states; 443/443 rows machine-verified; Gell-Mann–Okubo residual 0.57%; 0 isospin sign mismatches.
QUOTE: "442 distinct PDG-2024 states accounted for individually (constituents, additive quantum numbers, spin/parity audited); a fail-closed machine-verification suite reports 443/443 rows consistent"
SOURCE: https://physics.magflowmeters.com/particles/
STATUS: quantum-number closure/consistency; hadron masses are imported, not geometry-derived — "a clean regression run is not a proof."

### Anyone can re-run the whole thing with one command — and tampering shows up automatically
PLAIN: Every frozen object carries a SHA-256 fingerprint combined into one master hash, and a single script regenerates every published number byte-for-byte and fails closed on any mismatch — so "we refined it after seeing the data" and "we tuned it" are formally the same act, and both void the certificate.
NUMBER: 33-item manifest, all 33 hashes verified, meta-hash a5b1e6f9d951; the deterministic reproducer (pure Python + numpy, no random seeds) regenerates every certificate CSV and re-verifies all 33 hashes on re-run.
QUOTE: "[ok] All 33 per-item hashes match / [ok] Manifest meta-hash matches: a5b1e6f9d951" and "From that moment, 'we refined it' and 'we tuned it after seeing the data' are formally the same act, and both invalidate the certificate."
SOURCE: Fable_GUT_merged parts 4, 8, 11, 17; https://physics.magflowmeters.com/gates/dossiers/sg1.html; https://physics.magflowmeters.com/shape/
STATUS: verified reproducibility posture; the corpus insists hashes certify which object was tested, not that the physics is true.

### A pure math identity — not a human — caught the computation's one error
PLAIN: An early engine pass produced a wrong curvature ratio, and the Bianchi identity — a mathematical consistency law that knows nothing about the desired answer — flagged it; the corrected exact value 23/75 was then proved by three independent target-blind routes, and the wrong values are retained as labeled negative controls so they can never drift back in.
NUMBER: wrong 31/147 (Bianchi max residual 1/7 ≈ 0.143) corrected to 23/75 (residual 3.05×10⁻¹⁶, machine precision); 3 independent routes agree.
QUOTE: "The criterion that caught this was the first Bianchi identity itself — a mathematical theorem satisfied by any Riemannian curvature tensor, with no reference whatsoever to any target value ... The fix ... is a one-line relative-sign flip" (corrected value 23/75, first Bianchi residual 3.05×10⁻¹⁶)
SOURCE: https://physics.magflowmeters.com/gates/dossiers/gap01.html and uqf5c.html
STATUS: documented, disclosed correction; retracted values kept as named negative controls.

### The geometry's quantum framework collapses to the exact textbook formula — with no dial to force the match
PLAIN: Reduced all the way down to ordinary quantum mechanics, the three-qubit error-correction code's failure rate comes out as the exact textbook formula, with no geometric parameter available to fake it — a mismatch would have been fatal.
NUMBER: logical error rate = 3p² − 2p³, exact match.
QUOTE: "the code's logical error rate should come out as the plain textbook formula 3p² − 2p³, with no geometric parameter to hide behind. Matched — a mismatch here would have been fatal"
SOURCE: https://physics.magflowmeters.com/tests/quantum-computer.html
STATUS: matched consistency check, per the corpus.

### The QCD scale computed twice, then the geometry deliberately deleted — nothing changed
PLAIN: The strong force's confinement scale was computed by two independent algorithms agreeing to ten decimal places, and then the geometry's own threshold correction was deleted and everything recomputed to prove no hidden geometric bridge was smuggling in the answer — the result was bit-identical.
NUMBER: Λ_QCD = 45.036 MeV both routes; relative difference 1.737×10⁻¹⁰; with δ₃ removed: bit-identical.
QUOTE: "δ₃ → 0 leaves the IR answer bit-identical" — a "target-blind removal-and-recompute test on the geometric threshold correction δ₃"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/deeproot-scale.html
STATUS: derived-from-a-measured-seed exactly as ordinary QCD; run as a target-blind honesty check, not claimed as a hierarchy bridge.

### Every integrity check ships with a proof it can fail
PLAIN: The consistency checks are exact-fraction arithmetic shipped with deliberate sabotage tests that must fail — nudging one charge from 1/6 to 1/5 breaks four anomaly traces on cue — and the quantum paper's eight runnable integrity certificates all pass while all eight negative controls correctly fail.
NUMBER: 8 runnable certificates, 8 PASS, 8 negative controls FAIL_CONFIRMED; Y = 1/6 → 1/5 sabotage fails four traces.
QUOTE: "perturbing Y(Q_L) from 1/6 to 1/5 fails four traces with nonzero exit code — the pass condition is non-vacuous"
SOURCE: Fable_GUT_merged part 7; Fable_Quantum_merged part 13
STATUS: certificate-complete with negative controls; the pass conditions are demonstrated non-vacuous.

### The framework's bookkeeping reproduces textbook physics digit for digit
PLAIN: On a fully worked charged-shell problem the framework's three-layer accounting and standard Einstein–Maxwell theory compute the identical energy to six significant figures at every intermediate step, and the weak-field limit lands exactly on Newton's gravity equation and Coulomb's law — the new machinery reduces to known physics rather than replacing it.
NUMBER: U_EM = 4.49378×10⁸ J (six significant figures, both methods); ∇²Φ = 4πGρ recovered.
QUOTE: "the traditional Einstein–Maxwell audit and the full \(\times,\oplus,\otimes\) conservation audit ... are not merely 'consistent' or 'compatible'; they are arithmetically identical at every intermediate step."
SOURCE: Fable_GUT_merged parts 1, 28; Fable_Quantum_merged parts 5, 12; Fable_Forces_merged parts 2–3; TOE_FINAL_merged part 1/4
STATUS: consistency check only — "a sanity check, not a discovery"; explicitly does not replace GR; the gravity interface is conditional on the volume-modulus freeze.

### The calculation engines reproduce every textbook answer before being trusted
PLAIN: Before the heat-kernel and spectral machinery was applied to the new 13-D geometry, it was made to reproduce exact known textbook answers — sphere coefficients to one part in a thousand trillion, the sphere zeta value −1/15, and a standard lattice reference number hit to 0.025σ — including a control confirming the internal shape is not secretly a round sphere.
NUMBER: a₆(S²)=4/315 to ~10⁻¹⁵; ζ_S²(−1) = −1/15 exact; lattice plaquette 0.59375 vs reference 0.5937 (0.025σ).
QUOTE: "The present computation reproduces the S^2 ratio to relative error ∼10⁻¹⁵ via high-precision Richardson/Vandermonde extrapolation, and reproduces the full sphere ladder (with S^6 giving exactly a_4=12, confirmed as a passed control that K_6 is not S^6)"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/uqf9.html, uqf10.html, gap01.html, gap02.html
STATUS: passed calibration controls inside the respective closures.

### The same shape that fixes the forces designs a working (simulated) quantum computer
PLAIN: The identical six-dimensional geometry that forces three particle families also defines the admissibility rules of a quantum-error-correction architecture implemented as runnable code and exercised against a real decoder at ~100 million shots — needing roughly 10–14 physical qubits per protected qubit at scale versus about 24 for IBM's comparable published scheme, with the overhead band holding from hundreds to tens of thousands of logical qubits.
NUMBER: physical-to-logical memory overhead ~9.6–14.5× (conservative fallback 3.24×) vs IBM qLDPC ~24:1; ~10⁸ decoded shots; biased-noise decoder advantage ~8.4× (CI 4.2–16.9).
QUOTE: "the same K6 = SU(3)/T² flag-manifold geometry that forces three fermion families into existence ... turn out to be the same mathematical object as the admittance algebra of a quantum-error-correction architecture that has been designed and simulated"
SOURCE: https://physics.magflowmeters.com/tests/quantum-computer.html; Fable_GUT_merged parts 1, 6; Fable_Quantum_merged parts 1, 12; TOE_FINAL_merged part 3/4; https://physics.magflowmeters.com/quantum/
STATUS: SIMULATED / BOUNDED, honest engineering grade — a simulated design, not a fabricated chip; no specific overhead ratio treated as settled pending an independent replay (the corpus's own label); it changes no physics status and feeds no numbers back; the design is recorded as FAILING the Shor-2048 error budget, and formerly-quoted sub-2 ratios are retired on the record.

### Seventeen quantum-consistency gates, zero failures
PLAIN: The 13-D theory was pushed through a 17-gate quantum-consistency audit — ghosts, anomalies, unitarity, positivity, hidden-force leakage — and not a single gate failed; every row below certificate tier carries a named research path, with the hardest open items shared field-wide.
NUMBER: 17 gates: 3 CERTIFICATE + 6 CANDIDATE + 8 AUDIT + 0 FAILED.
QUOTE: "The visible distribution is therefore: 3 CERTIFICATE + 6 CANDIDATE + 8 AUDIT + 0 FAILED."
SOURCE: Fable_Quantum_merged part 13/13
STATUS: aggregate Σ = AUDIT by the paper's own weakest-link rule — "structurally complete ... not yet a candidate-tier closure," the corpus's own words.

### The manuscript polices its own claim boundary by machine — zero violations
PLAIN: A mechanical, answer-blind check ran over the entire 15,507-line manuscript and confirmed that all seven topics the theory does NOT claim to solve are openly declared, and that no claimed result secretly leans on any of them.
NUMBER: 7/7 excluded sectors disclosed; 0 violations across 11 scanned certificate regions (all CLEAN, exit code 0); 15,507 lines checked.
QUOTE: "every one of the seven sectors the scoped GUT does not address ... is named in the §9.4 boundary ledger" and no required gate "is closed by exclusion — neither by quietly leaning on an excluded sector for support, nor by re-filing a required gate as an exclusion"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/sg10.html
STATUS: DERIVED-GIVEN-anchor · RESOLVED +0; explicitly a disclosure-practice result, not a physics result.

### Every record the cosmic story needs fits inside physics' information limit — with 15–34 orders to spare
PLAIN: A self-audit checks that all the records the early-universe reconstruction relies on would actually fit within the universe's hard information-storage ceiling — and they do, with 15 to 34 orders of magnitude of headroom.
NUMBER: ceiling ≈ 2×10¹²² k_B vs actual ~10⁸⁸–10¹⁰³ k_B.
QUOTE: "a ceiling of ≈2×10¹²² k_B versus an actual paid bill of ≈10⁸⁸–10¹⁰³ k_B — a margin of 15 to 34 orders of magnitude"
SOURCE: https://physics.magflowmeters.com/early-universe/tests/
STATUS: Agrees (corpus label; consistency check, not a new prediction).

## FORCED-NOT-FITTED

### Two measured numbers in, nineteen-plus flavor numbers out
PLAIN: Standard physics needs ~20 hand-inserted numbers for particle masses and mixings — here exactly two measured inputs are committed once and nineteen-plus independent flavor quantities come back out, frozen before comparison, with per-family tuning structurally banned.
NUMBER: 2 anchors (y_t = 0.9665, |V_us| = 0.22436) → 19+ outputs (13 in the quark sector alone); best hit |V_cb| at 0.005σ, worst |V_ud| at 1.54σ.
QUOTE: "Binding compression statement. Two inputs \(\to\) nineteen-or-more outputs \(\to\) zero fitted entries." and "calibrated by exactly two measured numbers, y_t(M_Z)=0.9665 and |V_us|=0.22436, forces the entire pattern of Standard-Model flavor structure ... with per-family tuning structurally banned"
SOURCE: Fable_GUT_merged parts 5–6, 17, 26–27; https://physics.magflowmeters.com/gates/dossiers/sg8.html; https://physics.magflowmeters.com/tests/two-to-nine.html
STATUS: DERIVED-GIVEN-anchor · RESOLVED +0 / "Certificate-complete under declared assumptions" — the corpus calls it parameter-counted compression, explicitly not a zero-input derivation; sector scales (m_b, m_τ) are separately paid calibration inputs.

### Electron, muon, and tau masses with zero lepton inputs
PLAIN: The three charged-lepton masses come out of the frozen geometry with no lepton measurement fed in at all, landing within hundredths of a standard deviation of experiment.
NUMBER: m_e = 0.4869 vs 0.48657 MeV (pull 0.07σ); m_μ = 102.7 vs 102.718 MeV (0.02σ); m_τ = 1746 vs 1746.17 MeV (0.01σ).
QUOTE: "No charged-lepton anchor (no \(m_\tau\) or \(m_\mu / m_e\) input)." ... "\(m_e(M_Z)\) [MeV] Output \(0.4869 \pm 0.0050\) ... \(0.48657 \pm 0.00007\) ... \(0.07\)"
SOURCE: Fable_GUT_merged parts 8, 17, 27; https://physics.magflowmeters.com/particles/
STATUS: Certificate-complete under declared assumptions (derived given the two flavor anchors).

### The up-quark mass: a forced 1/√6 turns the theory's one public miss into a +0.058σ hit
PLAIN: The theory's admitted worst number — an up-quark mass forced to 3.16 MeV against the measured 1.27, a ~4.4σ miss it published on its own front pages — is resolved by a dimensionless factor 1/√6 fixed purely by the six-element symmetry group of the flavor shape, moving the prediction to 1.295 MeV and leaving it standing as a sharp falsifiable prediction.
NUMBER: 1/√6 = 1/√|S₃| (group order 6); m_u moves 3.16 MeV → 1.295 MeV vs measured 1.27 ± 0.43 MeV, pull +0.058σ.
QUOTE: "This 1/√6 is fixed by the geometry — a finite, dimensionless, same-layer factor native to the K₆ flavor carrier — not a decimal chosen to hit the measured value. ... z = (1.294838767 − 1.27)/0.43 = +0.0578 σ"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/sg8.html; https://physics.magflowmeters.com/residuals/; https://physics.magflowmeters.com/toe/; https://physics.magflowmeters.com/gates/ (SG-8)
STATUS: DERIVED-GIVEN-anchor · RESOLVED +0 on the current board (the dossier's 2026-07-07 ledger patch marks SG-8 CLOSED/RESCUED, superseding the earlier CLOSED-NEGATIVE grading); the earlier ~4.4σ version is still displayed in the older GUT/Quantum papers and wall register — the corpus shows both rather than hiding the history, and the fix changed only a silently-set 13D→4D comparison factor, no measured value.

### One angle in, the whole quark-mixing matrix out
PLAIN: After one measured mixing number pins one angle, every other entry of the quark mixing matrix and the CP-violation strength are forced — and land on the measured values to hundredths of a sigma.
NUMBER: |V_cb| = 0.0408 vs PDG 0.04079 (0.005σ); |V_ub| = 0.00378 vs 0.00382; Jarlskog J = (2.92 ± 0.40)×10⁻⁵ vs PDG (3.00 ± 0.13)×10⁻⁵ (0.21σ).
QUOTE: "One angle is consumed; everything else in the mixing sector is now forced: |V_ub| = 0.00378 (PDG 0.00382), |V_cb| = 0.0408 (PDG 0.04079)"
SOURCE: Fable_GUT_merged parts 6, 17; https://physics.magflowmeters.com/gates/ (SG-8); https://physics.magflowmeters.com/residuals/
STATUS: DERIVED-GIVEN-anchor · RESOLVED +0 / Certificate-complete frozen outputs.

### The matter–antimatter angle read off a geometric twist, not a dial
PLAIN: The CP-violating phase — a pure free parameter in the Standard Model — is read off an order-three winding of the internal geometry as exactly −120°, which in the standard convention compares as +60.0° against the measured 65.5° — under one sigma off, with no free phase available to insert.
NUMBER: δ_CKM = −2π/3 = −120.0° exactly (raw); Wolfenstein-aligned +60.0° (declared ~10% structural precision, pull computed as (65.5−60.0)/6.9) vs PDG 65.5° ± 1.5° → 0.79σ; rejected alternative corner (τ=i, −90°) excluded by PDG at >5σ.
QUOTE: "Both CP phases are read from order-three holonomy, not fit: δ_CKM = −2π/3 = −2.094395102393195 rad = −120.0°"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/sg8.html; Fable_GUT_merged parts 1, 6, 10, 17, 27; TOE_FINAL_merged part 1/4
STATUS: DERIVED-GIVEN-anchor · RESOLVED +0; the corpus itself says a sub-1σ pull is "a non-falsification, never a confirmation."

### The Higgs numbers come out as outputs, not inputs
PLAIN: The two numbers that set the scale of all particle masses — the Higgs field's vacuum value and the Higgs boson's mass — are computed from a frozen geometric loop (a Wilson line), landing at 246.02 GeV vs the measured 246.22 and 123.82 GeV vs the measured 125.10.
NUMBER: v_pred = 246.02 ± 3.5 GeV (0.06σ); m_h = 123.82 ± 1.8 GeV vs 125.10 ± 0.14 GeV (0.48σ); one structural source for both.
QUOTE: "The chamber-frozen output is \(v_{\rm pred} = 246.02 \pm 3.5\) GeV ... inside the PDG band of \(246.22\) GeV at \(0.06\sigma_{\rm th}\)" and "The mass is a structural output of the chamber-determined potential, not a tuned counterterm."
SOURCE: Fable_GUT_merged parts 5, 9, 14, 22, 26; https://physics.magflowmeters.com/shape/
STATUS: Claimed certificate pass (Gate 8) — the corpus explicitly does NOT claim a first-principles derivation of the Higgs mass; the /gut/ page grades v and m_h as "near-hits" within a partial consistency pass.

### Eight neutrino-sector numbers from zero further inputs
PLAIN: With no neutrino data fed in, the same structure returns both neutrino mass splittings, all three mixing angles, and a leptonic CP phase of about 260 degrees that sits inside the current global-fit band.
NUMBER: δ_CP(lepton) ≈ 260.2° ± 10°, inside the NuFIT band [195°, 270°]; Δm²₂₁ = 7.39 vs 7.42 ×10⁻⁵ eV² (pull 0.14σ); 8 observables from 0 further inputs.
QUOTE: "returns the mass-squared splittings, all three PMNS angles, and the leptonic CP phase δ_CP ≈ 260.2° (NuFIT band [195°, 270°]) — eight further observables from zero further inputs"
SOURCE: Fable_GUT_merged parts 6, 17, 27; https://physics.magflowmeters.com/tests/two-to-nine.html
STATUS: Certificate-complete under declared assumptions (lower-octant solution); future DUNE/JUNO tightening is the named falsifier.

### The whole mass staircase hangs off one geometric constant
PLAIN: Instead of nine unrelated fermion masses, every within-sector mass step is a power of a single geometric constant e^(−π√3) ≈ 1/231 fixed at the hexagonal symmetry point of the shape — the top-to-charm and charm-to-up ratios are forced to be the same number, about 231, with per-family fudge factors formally forbidden.
NUMBER: κ = e^(−π√3) = 0.004333420509983131; m_t/m_c = m_c/m_u = e^(π√3) ≈ 231; m_b/m_s = m_s/m_d ≈ 38.5; m_μ/m_e ≈ 207 falls out of the same ladder.
QUOTE: "the forced equal-log-step up ladder gives m_t/m_c = m_c/m_u = e^{π√3} ≈ 230.76, and the down ladder gives m_b/m_s = m_s/m_d = e^{2π√3/3} ≈ 38.5" and "family-level normalizations \(N_{i,a}\) are explicitly forbidden ... what makes the chamber's per-family hierarchy a prediction ... rather than a fit."
SOURCE: https://physics.magflowmeters.com/gates/dossiers/sg8.html; Fable_GUT_merged parts 6, 10, 18; https://physics.magflowmeters.com/shape/
STATUS: DERIVED-GIVEN-anchor · RESOLVED +0; ladder-exponent map graded SHAPE-SUPPORTED/open by the /shape/ page until exhibited as discrete winding classes.

### The W/Z mass relation was a test the geometry could have failed — and passed
PLAIN: The shape does not contain the hidden symmetry that would make the famous W/Z ratio come out 1 automatically, so deriving ρ = 1 exactly from real overlap integrals on the sphere is a genuine geometric result confronted with the measured 1.00038 — and the deliberately wrong operator on the same geometry gives garbage, proving the result is not a tautology.
NUMBER: ρ_tree = 1 exactly vs measured ρ₀ = 1.00038 ± 0.00020; wrong-operator control gives ρ ∈ [1/2, ∞).
QUOTE: "ρ_tree = M_W²/(M_Z² cos²θ_W) = 1 exactly, derived from real ∫_{S²} monopole-doublet overlap integrals together with a rigidity theorem ... not assumed by an appeal to an enlarged custodial symmetry group bolted on for the purpose"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/sg5.html; https://physics.magflowmeters.com/gates/ (SG-5)
STATUS: DERIVED-GIVEN-anchor · RESOLVED +0 (electroweak scale taken from experiment as a second ruler); the dossier itself discloses that an earlier interim computation used the wrong operator and was superseded — the wrong-operator result is retained as the negative control.

### The top-to-bottom coupling ratio hits at a tenth of a sigma
PLAIN: The ratio of the top quark's coupling to the bottom quark's — a number the Standard Model just measures — comes out of the same frozen geometric determinant that produces the Higgs numbers, landing at 57.50 against the measured ≈58.
NUMBER: |y_t/y_b|(M_Z) = 57.50 predicted vs measured ≈ 58, pull 0.10σ; raw closed-form source 1/η_BK = 32π·exp(√3/(24π)) ≈ 102.87 before standard running.
QUOTE: "the structural identity \(1/\eta_{BK} = 32\pi\exp(+\sqrt{3}/(24\pi)) \approx 102.87 = |y_t/y_b|\) ... one chamber input, two Standard Model outputs"
SOURCE: Fable_GUT_merged parts 1, 6, 22
STATUS: Certified prediction (M_Z value), certificate-complete under declared assumptions.

### Every electric charge lands exactly on a 1/6 grid, with nothing assigned by hand
PLAIN: The strange fractional charges of quarks (+2/3, −1/3, with bulk-matter neutrality measured to roughly one part in 10²¹) are forced by a six-fold gluing of the three force sectors' centers, and feeding the resulting grid through Q = T₃ + Y reproduces the entire measured charge table with zero per-particle adjustment — a wrong charge like Y = 1/5 is geometrically inconsistent, not just unobserved.
NUMBER: Y ∈ (1/6)ℤ; Q(u) = +1/2 + 1/6 = +2/3; Q(d) = −1/2 + 1/6 = −1/3; gauge group (SU(3)×SU(2)×U(1))/ℤ₆; Smith normal form [1,6,6].
QUOTE: "Feed that lattice through Q=T_3+Y once per multiplet and the entire one-generation charge table drops out with no per-multiplet adjustment: ν lands at exactly Q=0, d_R at exactly −1/3, and every other entry matches the Particle Data Group values on the nose."
SOURCE: https://physics.magflowmeters.com/gates/dossiers/sg4.html; Fable_GUT_merged parts 4, 9, 16–17, 20–21; https://physics.magflowmeters.com/gates/dossiers/deeproot-shape.html
STATUS: REDUCED-TO-AXIOM · ANCHORED +1 (given the observed particle spectrum; the corpus explicitly does not claim this selects the Standard Model uniquely — GUT part 16 notes the 1/6 lattice and Q = T₃+Y are "empirical observations (PDG), not derived from a higher principle").

### Six make-or-break quantum-consistency sums land on exactly zero — and the cancellation is not a triviality
PLAIN: The six anomaly-cancellation sums that must all vanish for the Standard Model to make quantum sense come out exactly zero in whole-fraction arithmetic on the geometry's own charge table, verified on two independent routes — while a nearby look-alike sum comes out 10/3, proving the pass is a real conspiracy of unequal fractions, and a deliberate sabotage (nudging one charge to 1/5) fails four traces on cue.
NUMBER: 6/6 anomaly sums = 0 exactly (e.g. cubic ledger (1 − 32 + 4 − 9 + 36)/36 = 0); non-triviality witness ΣY² = 10/3 ≠ 0.
QUOTE: "six independent quantum-consistency witnesses ... all vanish exactly, in finite rational arithmetic that a referee can check by hand in an afternoon. That the cancellation is not a triviality is independently certified by ΣY² = 10/3 ≠ 0"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/sg4.html; https://physics.magflowmeters.com/gates/dossiers/uqf4.html and uqf7.html; Fable_GUT_merged parts 3, 7, 16, 20; https://physics.magflowmeters.com/gates/ (UQF-4, SG-4)
STATUS: DERIVED-GIVEN-anchor · RESOLVED +0 (one-generation matter content fed in, not derived; the corpus explicitly refuses to claim anomaly cancellation "selects" the Standard Model).

### The Higgs winding integer is forced — the alternatives fail by 60 sigma or give no matter masses
PLAIN: The one discrete choice in the Higgs mechanism is no choice at all: winding zero gives a universe with no electroweak symmetry breaking, and winding two puts the Higgs vacuum value off by roughly 60 standard deviations, so 1 is the only survivor.
NUMBER: n_H = 1; n_H = 2 → VEV ~492 GeV, ~60σ off; n_H = 0 → v = 0.
QUOTE: "\(v_{\rm pred}\) scales by integer factor; PDG band missed by \(\sim 60\sigma\) for \(n_H = 2\)"
SOURCE: Fable_GUT_merged part 22 (elimination ledger C9.5)
STATUS: Elimination ledger inside the Gate-8 certificate; each alternative fails a named constraint.

### Four measured numbers run the whole reconstruction — with more answers than questions
PLAIN: The full framework reads only four measured anchors (Planck mass, gauge couplings, top-quark coupling, one mixing element) and returns 22+ independent quantities — the pattern of forces, mixings, the family count, the electroweak scale — the opposite of curve-fitting.
NUMBER: 4 declared anchors → 22+ independent outputs; honest whole-construction compression ≈ 3.7–4.4× (~22 outputs from ~5–6 effective inputs).
QUOTE: "Against those four inputs, the geometry returns 22+ independent quantities ... More outputs than inputs is the fingerprint of a theory that is constrained, not curve-fitted." and "The honest whole-construction compression is \(\approx 3.7\)–\(4.4\times\) ... not a zero-input derivation, and never claimed as one."
SOURCE: https://physics.magflowmeters.com/toe/; https://physics.magflowmeters.com/shape/; Fable_GUT_merged parts 9, 14; TOE_FINAL_merged part 1/4
STATUS: Derived given the four anchors; the corpus's own framing is "over-determination, not derivation" and "a fingerprint, not a finished proof of nature."

### The strong force's strength read from the volume of the shape
PLAIN: The strong coupling constant — a free dial in the Standard Model — is fixed by the volume of the compact color geometry and, run down to laboratory energies, lands on the measured value within its error bar.
NUMBER: predicted α₃(M_Z) ≈ 1/8.5 vs PDG 1/8.47 ± 0.05.
QUOTE: "the strong coupling \(\alpha_3(M_Z)\) are framework-fixed (the latter from \(\mathrm{Vol}(K_6)\) at the UV matching scale; running with KK threshold corrections to \(M_Z\) yields \(\alpha_3(M_Z)\approx 1/8.5\), consistent with the PDG value \(1/8.47\pm 0.05\))"
SOURCE: Fable_Quantum_merged parts 7, 13
STATUS: Stated as framework-fixed and PDG-consistent inside an AUDIT-tier section of Paper 3 (the surrounding nonperturbative-QCD gate is honestly open field-wide); note the gauge couplings α_i(M_Z) are declared anchors in the GUT paper's own accounting.

## QM-CANT-WE-CAN

### Why quantum odds are amplitude SQUARED — the exponent 2 is pinned, and experiment already checked
PLAIN: Standard quantum mechanics simply postulates probability = amplitude squared; here the exponent 2 is pinned as the unique power that conserves probability in every basis and produces zero three-way interference — and triple-slit experiments measured that three-way interference and found it zero.
NUMBER: exponent p = 2 exactly; Sorkin parameter ε ≈ 0 measured (Sinha et al. 2010, and tightened repetitions since), and ε vanishes identically if and only if p = 2.
QUOTE: "Sorkin's third-order interference parameter \(\varepsilon\) vanishes identically if and only if \(p=2\); triple-slit experiments (Sinha et al. 2010 ...) measure \(\varepsilon\approx 0\). This is a passed, measured falsifier"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/born.html; https://physics.magflowmeters.com/gates/ (Born)
STATUS: REDUCED-TO-AXIOM · ANCHORED +1 as a gate (two named value-free axioms: non-contextuality — after which Gleason's theorem delivers the trace form — plus a chamber-selector posit); the exponent p = 2 itself stands separately as a measured, empirically pinned result, prior to both axioms; the corpus does not claim a from-nothing derivation.

### The strong-CP puzzle: exactly zero, with no axion, no new particle, no tuning
PLAIN: A puzzle physicists usually fix by inventing a new particle (the axion, hunted for decades and never found) simply disappears: both quark mass patterns come from one real geometric frame, so the strong force's mirror-breaking angle is forced to exactly zero — comfortably inside the neutron's measured bound — while the same machinery correctly KEEPS the weak sector's real CP violation at 0.21σ from data.
NUMBER: predicted θ̄ = 0 exactly vs experimental (neutron-EDM) bound ~10⁻¹⁰; no Peccei–Quinn field, no axion, no new symmetry, zero not fitted; control: Jarlskog J = (2.92±0.40)×10⁻⁵ vs measured (3.00±0.13)×10⁻⁵ (0.21σ pull), not washed out.
QUOTE: "the puzzle does not get solved by tuning a number to 10⁻¹⁰: it dissolves because the geometry never manufactures a phase to tune in the first place" and "no Peccei–Quinn field, no axion, and no new symmetry posited anywhere in the construction"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/theta-qcd.html; https://physics.magflowmeters.com/gates/ (θ̄-QCD)
STATUS: DISSOLVED-GIVEN-Shape · RESOLVED +0 on the gates board; the corpus states the bare topological angle is not separately computed (a falsifiable forecast that it also returns 0 stands), and the earlier Paper 3 held its own strong-CP row deliberately open at AUDIT (named candidate, LOW confidence) — both statuses are the corpus's own, at different dates.

### The hierarchy problem dissolved by an integer that cannot creep
PLAIN: Why the Higgs isn't dragged up fourteen orders of magnitude by quantum corrections — the Standard Model's worst fine-tuning, normally requiring two enormous numbers to agree to twenty-eight digits — is answered by topology: the Higgs is a loop-phase controlled by a whole winding number, and no smooth correction can change an integer.
NUMBER: n_H = 1; avoids ~1-in-10²⁸ tuning; destabilizing correction would require a non-integer winding shift.
QUOTE: "the cure used here is to make the Higgs a quantity that cannot drift: a loop-phase whose controlling datum is a whole number. Whole numbers do not creep."
SOURCE: Fable_GUT_merged parts 3, 5, 19, 22, 26; https://physics.magflowmeters.com/gates/dossiers/sg5.html
STATUS: Gate 8 = Claimed certificate pass at one loop; Diagnostic only at higher loops (the corpus's explicit, acknowledged scope limitation — an all-orders loop-resummation proof is not provided); the absolute electroweak scale remains a measured anchor.

### Why nature is left-handed: a boundary of space, not a postulate
PLAIN: The Standard Model writes in by hand that the weak force only touches left-handed particles (the 1957 shock); here handedness is enforced by the folded circle's boundary parity, which structurally leaves no place for the mirror partners to exist at the zero-mode level — parity violation is built into the shape.
NUMBER: 15 left-handed Weyl states per generation (the standard count); 0 surviving mirrors at the 4D zero-mode level.
QUOTE: "the \(\mathbb Z_2\) projection on \(S^1_Y\) is the structural mechanism that makes parity violation automatic."
SOURCE: Fable_Quantum_merged parts 7, 9; Fable_Forces_merged part 3/4
STATUS: CERTIFICATE at the classical zero-mode level (UQF-7B); the narrow quantum-descent residual (whether the quantized 13D→4D descent introduces a light mirror not present in the classical count) is the named open item, honestly held at AUDIT.

### The Higgs is not an inserted particle — it is a loop of the force field
PLAIN: The Standard Model must declare the Higgs into existence as a brand-new fundamental field; here it is the phase the gauge field winds up when it circles a non-shrinkable loop of the internal geometry — nothing new is added to the particle list.
NUMBER: winding number n_H = 1.
QUOTE: "The Higgs is not an inserted scalar; it is a holonomy."
SOURCE: Fable_GUT_merged parts 22, 26; Fable_Quantum_merged part 6
STATUS: Certificate-complete construction dossier (Appendix H / C9), while Gate 8 itself is Claimed certificate pass at one loop; Paper 3's tree-level quantization sub-row (UQF-8A) is CERTIFICATE-tier, with the measured EW VEV inherited as an input there (m_h² = 2λv²) — the corpus does not claim the Higgs mass is predicted from first principles.

### 'Probabilities never go negative' is a theorem at any finite resolution — and a new result maps the remaining wall
PLAIN: That quantum probabilities stay real and non-negative is proven outright for the physically relevant finite-resolution world — the only unproven piece is the infinitely-fine limit, the same wall as the Clay Millennium Yang–Mills problem — and as a by-product the framework proved a genuinely new scope theorem: positivity is a strictly smaller sub-problem of the mass-gap problem, with the dependency running one way only.
NUMBER: at any lattice spacing a > 0: transfer operator 0 ≤ T ≤ 1, H ≥ 0, unique vacuum, strictly positive finite-volume gap (explicitly flagged as not the Clay gap).
QUOTE: "positivity does not require a mass gap to hold. The dependency arrow runs strictly one way, gap-machinery → positivity"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/uqf3.html
STATUS: CERTIFIED-IRREDUCIBLE · RESOLVED +0; finite-cutoff positivity DERIVED, the continuum leg carried as a certified external wall shared with the Clay problem — explicitly not claimed.

### The arrow of time gets a computed mechanism, not a postulate
PLAIN: Instead of assuming entropy increases, the framework ran candidate arrow-of-time measures against its open-system dynamics and found exactly one universal quantity that never decreases — verified to machine precision — while the five expected failures failed exactly where they should.
NUMBER: 1 surviving monotone (Spohn's relative entropy), machine-zero violation; 5 expected failures named and counted.
QUOTE: "Spohn's relative-entropy functional D(ρ‖ρ_ss) is the surviving universal arrow monotone — monotone at machine-zero violation under both generic and thermal GKLS dynamics"
SOURCE: TOE_FINAL_merged part 2/4; Fable_Quantum_merged part 1/13
STATUS: PASS (closed-by-computation) within the GKLS dynamical class — scope-honest; the cosmological initial condition remains OPEN (Gap 06).

### Planck's constant demoted from postulate to residue — and the two counterexamples that prove the axiom is needed
PLAIN: Standard quantum mechanics postulates ħ; here the entire "reality is quantized" idea is compressed to one named value-free axiom — a positive minimum operational step — with ħ as nothing more than that step's measured size, and two explicit counter-models prove that finite resources alone would NOT give you the floor, which is exactly why it must be its own axiom.
NUMBER: one posit (Δ₀ > 0); ħ = its measured residue; two decisive countermodels.
QUOTE: "the floor's existence is compressed to one posit and one measured residue; the no-derivation is earned by two decisive countermodels, not asserted by fiat"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/deeproot-granularity.html; https://physics.magflowmeters.com/granularity/; https://physics.magflowmeters.com/building-blocks/
STATUS: REDUCED-TO-AXIOM · ANCHORED +1; the value of ħ is never derived, and the corpus rates a future full pre-quantum derivation at ~15–20% odds (named open hole).

### The Born rule split into exactly two named assumptions — with a countermodel proving nothing is smuggled
PLAIN: Every published attempt to derive quantum theory's probability rule imports an assumption as strong as the rule itself; this framework's gate-specific contribution is to split the rule into two legs graded separately rather than bundled into one opaque assumption, reduce each to one explicit value-free axiom, and prove by a pencil-and-paper three-state countermodel that its own gauge machinery does not secretly force the rule — so the import is on the record, not hidden.
NUMBER: exactly 2 named axioms; a dimension-3 countermodel satisfying every gauge constraint while violating non-contextuality.
QUOTE: "Every one of these programs, without exception, imports an assumption that is exactly as strong as the rule it is trying to derive ... the Born rule's two logically independent components ... each reduce to a single, explicit, value-free, target-blind axiom"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/born.html; https://physics.magflowmeters.com/quantum/
STATUS: REDUCED-TO-AXIOM · ANCHORED +1 — "anchored is not derived," per the corpus; Paper 3's own text calls the rule as a whole open, with the countermodel as the checkable win.

## UNIFICATION

### The three forces are the built-in symmetries of one 13-dimensional shape — exactly, with none left over
PLAIN: The strong, weak, and hypercharge forces are not three separate postulates: each is the rotation symmetry of one factor of a single frozen 13-D geometry (color from a 6-D flag manifold, the weak force from a 2-sphere's spin cover, hypercharge from a folded circle), and computing the surviving symmetries returns exactly the Standard Model's 12 force carriers — 8 gluons + 3 weak bosons + 1 — with no missing and no extra force.
NUMBER: D = 4 + 6 + 2 + 1 = 13; 8 + 3 + 1 = 12 generators, rank 4, exactly su(3)⊕su(2)⊕u(1).
QUOTE: "the surviving 4-dimensional isometry algebra of the three internal metric factors is computed, not assumed, and it comes out exactly equal to the Standard Model gauge algebra"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/sg2.html; https://physics.magflowmeters.com/shape/; Fable_GUT_merged parts 4, 7, 20–21, 25; https://physics.magflowmeters.com/gut/
STATUS: REDUCED-TO-AXIOM · ANCHORED +1 (one named axiom: forces are the internal geometry's rigid symmetries); the corpus itself flags that recovering the gauge group is a filter rival frameworks also pass, and the shape is "selected, not derived."

### Gravity falls out of the same shape as the forces — with exact integer counts and no extra dial
PLAIN: The identical frozen 13-D geometry that carries the gauge forces, three generations, and quark masses also produces a graviton with exactly two polarizations, light-speed propagation, and Newton's law at long distance — every integer in the bookkeeping forced by counting (fiber weights 91 raw components, ghost subtractions on a 13-component bundle, net 65), and its key curvature ratio an exact fraction proved three independent ways.
NUMBER: 2 helicities; field counts 91 / 13 / net 65; |Riem|²/Scal² = 23/75 exactly (First-Bianchi residual 3.05×10⁻¹⁶, machine zero).
QUOTE: "The same frozen thirteen-dimensional arena that carries the Standard Model's gauge group, its three chiral generations, and its Yukawa structure also carries a graviton — and it does so without a single additional dial."
SOURCE: https://physics.magflowmeters.com/gates/dossiers/uqf5a-5b.html and uqf5c.html; https://physics.magflowmeters.com/gates/ (UQF-5A/5B); Fable_Quantum_merged parts 1, 4–5
STATUS: CERTIFIED-IRREDUCIBLE · RESOLVED +0 at the linearized level; the strong-coupling quantum-gravity completion (UQF-5C, separately ANCHORED +1) is exported as the wall every research program shares.

### The three force strengths meet at one point — with the corrections frozen before the couplings were loaded
PLAIN: Run up in energy with threshold corrections computed from the shape's own overtone spectrum (a ledger locked before the measured couplings were loaded), the three gauge couplings converge to a single value at 10¹⁶ GeV, with the closure residual driven to the numerical solver's convergence floor — a pipeline floor the corpus itself is careful to flag as far below the ~10⁻³ physical measurement band, not a physical precision claim.
NUMBER: M_U = 1.000×10¹⁶ GeV (a declared closure-target convention); closure residual 9.6×10⁻¹¹ = solver floor (vs propagated measurement band ~10⁻³); threshold vector (+4.8424, −3.1112, −1.7313), no row a free parameter.
QUOTE: "Every row is a topological / representation-theoretic function of frozen bundle data (Dynkin indices, Euler characteristics, hypercharge sum \(\sum Y_f^2 = 10/3\), Wilson-line winding \(n_H = 1\)). No row is a free parameter."
SOURCE: Fable_GUT_merged parts 5, 9, 16, 19, 21–22, 26; https://physics.magflowmeters.com/gates/dossiers/gap02.html, uqf10.html, gap13.html; https://physics.magflowmeters.com/shape/
STATUS: Claimed certificate pass (threshold-unification gate); the couplings at M_Z are consumed as measured anchors — "only their common meeting at M_U is an output," and M_U is a declared closure-target convention.

### "Why don't the forces meet?" was the wrong question — and dissolving it saves the proton
PLAIN: The 50-year-old demand that the three forces must merge into one big group at one point dissolves because each force lives on a different factor of the shape — and precisely because there is no big unifying group, the proton-killing mediator particles of textbook GUTs simply do not exist, with the quoted lifetime (inherited from the proton-safety gate, SG-9) clearing the experimental floor by a margin of order 40× or more.
NUMBER: proton lifetime > 10³⁶ years vs Super-Kamiokande floor 2.4×10³⁴ years (margin ~40×); minimal SU(5)'s executed and falsified prediction was τ_p ~ 10³⁰ yr (experimentally dead by ~4 orders of magnitude).
QUOTE: "Color SU(3)_c, weak SU(2)_L, and hypercharge U(1)_Y descend from three different factors of the internal geometry ... The 'must-unify' question, taken as an a priori requirement, is dissolved."
SOURCE: https://physics.magflowmeters.com/gates/dossiers/sg7.html; https://physics.magflowmeters.com/gates/ (SG-7); Fable_GUT_merged part 21
STATUS: DISSOLVED-GIVEN-Shape + DERIVED-GIVEN-E (correction signs) · RESOLVED +0; threshold-correction magnitudes are honestly named as still owed, and the proton-safety certificate belongs to SG-9, cited rather than re-derived.

### Five textbook force strengths, zero new dials
PLAIN: The five separate force-strength constants of the textbooks (Newton's G, strong, weak, electric, Fermi) carry zero adjustable dials of their own here — each is routed from the frozen geometry or computed from the others, and two of them (e and G_F) become identities that would disprove the geometry outright if experiment disagreed.
NUMBER: 5 couplings, 0 new dials; e = gg'/√(g²+g'²); G_F/√2 = g²/8M_W².
QUOTE: "in this routing the five force strengths carry zero new adjustable dials of their own... two of them, $e$ and $G_F$, are not predictions at all but identities... An identity that disagreed with experiment would prove the geometry wrong."
SOURCE: https://physics.magflowmeters.com/forces/; Fable_Forces_merged part 1/4
STATUS: Derived-given-the-anchors ("over-determination, not a fit"); interface claims graded as such, with Paper-I certificates inherited, not re-closed.

## GRANULARITY-RESOLVES

### The black hole's infinite center becomes one finite number — and turning the axiom off brings the infinity back on cue
PLAIN: Textbook relativity says every black hole hides a point of literally infinite curvature; impose one axiom — a smallest step ℓ — and the infinity is replaced by an exactly computed finite value while the exterior stays exactly Schwarzschild, and the control most theories never get to run works: dial ℓ→0 and the textbook infinity returns smoothly.
NUMBER: K(0) = 24/ℓ⁴ (finite) vs K→∞; exterior K → 48m²/r⁶ identically; K(0;ℓ) → ∞ continuously as ℓ→0.
QUOTE: "turning the axiom off and watching the pathology come back on cue ... Send \(\ell\to0\): \(K(0)=24/\ell^4\to\infty\) continuously and monotonically — the same \(+\infty\) Schwarzschild returns"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/blackhole-singularity.html; https://physics.magflowmeters.com/gates/ (Black hole)
STATUS: CLOSED / DISSOLVED-GIVEN-root · RESOLVED +0, conditional on one named value-free axiom; the interior profile is disclosed as a representative ansatz, not derived.

### The 120-orders-of-magnitude vacuum catastrophe dissolves as a category error
PLAIN: The infamous claim that empty space should weigh 10¹²⁰ times more than observed comes from adding things up as if space were perfectly smooth and gravitating; a proven tensor identity shows the huge number was never able to curve spacetime in the first place — nothing needs to cancel to 120 decimal places — and the loophole (vacuum energy changing during cosmic phase transitions) was stress-tested and closed.
NUMBER: 10¹²¹ apparent discrepancy dissolved; verification sweep over 60 orders of magnitude, max residual 1.234×10⁻¹⁴ (floating-point noise); the wrongly-gravitating residual today is ≈ 0, with the largest surviving leftover ~10⁻⁴ of the observed dark energy — coming from the separate, correctly-gravitating radiation channel, not a near-miss cancellation.
QUOTE: "Nothing needs to cancel to 120 decimal places, because nothing was ever set up to require such a cancellation in the first place."
SOURCE: https://physics.magflowmeters.com/gates/dossiers/lambda-catastrophe.html; https://physics.magflowmeters.com/gates/ (Λ); https://physics.magflowmeters.com/walls/
STATUS: DISSOLVED-GIVEN-root · RESOLVED +0, resting on one named disclosed posit (trace-free coupling); the tiny measured value of Λ stays an honest measured anchor and is deliberately NOT explained.

### The black hole itself survives the cure — with an exact mass threshold found twice
PLAIN: Removing the singularity does not remove the black hole: a horizon exists only above an exactly computed critical mass, and a related light-ring threshold was computed once by exact algebra and once by a blind numerical scan that didn't know the answer — and they agree.
NUMBER: m_crit = (3√3/4)ℓ ≈ 1.299 ℓ; light-ring threshold m/m_crit = 0.809543081003105, confirmed by a blind scan (present at 0.90–0.99, absent at 0.70 and below).
QUOTE: "A genuine event-horizon-bearing black hole survives whenever the mass exceeds a computed critical value \(m_{\rm crit}=\tfrac{3\sqrt3}{4}\ell\approx1.2990381057\,\ell\)"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/blackhole-singularity.html
STATUS: exact results within the disclosed ansatz (a named open effective-source hole remains); part of the DISSOLVED-GIVEN-root closure.

### Why you can never see a lone quark — and when protons first became things
PLAIN: In record terms a free quark is something the universe can never pay to isolate while a proton can be — and asking when a proton record first becomes affordable lands on the same 20-microsecond, 156-MeV moment that lattice supercomputer QCD computes.
NUMBER: T_c ≈ 156.5 ± 1.5 MeV, t ≈ 20 µs.
QUOTE: "A free quark can't be paid for as a record (confinement bars isolating one); a proton/neutron can — that record opens exactly at T_c≈156 MeV, t≈20 µs."
SOURCE: https://physics.magflowmeters.com/early-universe/tests/
STATUS: Agrees (corpus label) — with the honest note that the framework "agrees with the lattice value, does not independently compute it."

### Reality's smallest step is a cost, not a pixel — so relativity survives untouched
PLAIN: Every "smallest length" idea for taming physics' infinities breaks relativity because lengths shrink for a moving observer; this framework's floor is on a Lorentz-scalar cost (action), which every observer agrees on — a smallest step of reality with no preferred frame, fixing the decades-old flaw in the minimal-length literature.
NUMBER: floor Δ₀ > 0 with ħ as its measured size; the floor's existence is triangulated by three established bounds (Margolus–Levitin, Landauer, Bekenstein) — cited as independent confirmation, not as the derivation (all three are theorems of quantum theory).
QUOTE: "A length floor would pick a preferred frame (length contracts) and break Lorentz invariance; a floor on a scalar picks no frame. This is the firewall against 'spacetime is discrete.'"
SOURCE: https://physics.magflowmeters.com/granularity/; https://physics.magflowmeters.com/gates/dossiers/deeproot-granularity.html, uqf9.html
STATUS: the cost-not-length link is DERIVED; the uniform floor itself is a declared axiom (REDUCED-TO-AXIOM · ANCHORED +1); no claim that space is pixelated.

### Half of the hardest problem in mathematical physics becomes a theorem on a grainy universe
PLAIN: The Clay Millennium mass-gap problem is only hard because of the infinitely-fine continuum limit — at any finite resolution everything it asks for is already a proven theorem — and the framework's finite-resolution axiom lets it decline that limit while the physical gap stays a measured fact.
NUMBER: at every finite lattice spacing a > 0 and finite volume L < ∞ the gap Δ(a,L) > 0 is an established theorem (Münster 1981, via the strong-coupling expansion).
QUOTE: "the finite-resolution (cost-floor) axiom lets the theory decline the infinitely-fine limit — a finite cell needs no continuum, and on it the gap is a theorem; but this is a named standing assumption that changes the hard question rather than answering it"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/gap02.html; https://physics.magflowmeters.com/residuals/
STATUS: DISSOLVED-GIVEN-AXIOM for the continuum-existence face only; the corpus's own words: "NOT a Clay solution" — the gap value enters as a measured anchor.

### A cost floor dissolves a whole class of zoom-in-forever infinities before they form
PLAIN: The irreducible quantum of cost provably dissolves one entire class of continuum-limit divergences in quantum gravity — the endlessly deepening tower of corrections — cleanly and without breaking relativity, while the corpus states plainly the other ten named ultraviolet walls remain untouched.
NUMBER: 1 of 11 named UV walls dissolved (the a→0 runaway tower); floor scale M* ≈ 7.467×10¹⁶ GeV.
QUOTE: "an irreducible quantum of cost/action, Δ₀ > 0 — not a smallest length — dissolves one entire class of continuum-limit divergences, Lorentz-cleanly, before it can form"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/uqf9.html
STATUS: proved class-dissolution theorem within CERTIFIED-IRREDUCIBLE · RESOLVED +0; DISSOLVED ≠ SOLVED per the corpus.

### The horizon problem forces inflation — from the record ledger too
PLAIN: The sky's temperature is identical across patches that could never have touched, and the record ledger independently refuses to let that shared record exist unpaid — demanding the same early inflationary stretch at 10⁻³⁴ seconds that standard cosmology invokes.
NUMBER: causal patch ~1–2° vs 180° uniformity at 1 part in 10⁵; fix at t ≈ 10⁻³⁴ s.
QUOTE: "both refuse to let super-horizon correlation exist unpaid, so their landing on the same inflationary fix is a real cross-check, not a coincidence"
SOURCE: https://physics.magflowmeters.com/early-universe/tests/
STATUS: Agrees (corpus label).

### "What came before the Big Bang?" gets dissolved, not dodged
PLAIN: Because recording anything costs granularity and that cost was once unpayable, the Big Bang is the beginning of the knowable rather than the beginning of time. It is like standing in the dark and asking what the surroundings look like: not observable, and no way for us to know. Nothing is fundamentally different about the second before and the second after — the only difference is that one is observable from our frame of reference and the other is not. No singularity is needed.
NUMBER: —
QUOTE: "'before' the Big Bang is not an earlier time at all; it is the absence of any record for time to be measured against. Asking what happened before is like asking what is north of the North Pole."
SOURCE: https://physics.magflowmeters.com/early-universe/tests/ and /early-universe/
STATUS: a reframing/dissolution the corpus presents as its own reading — "doesn't need new data to be useful."

### Motion through a continuum is free; only distinguishable change costs
PLAIN: The "infinitely many steps" worry about continuous motion dissolves: gliding through overlapping states costs nothing, only jumps to genuinely distinguishable states cost, and no finishable process can contain infinitely many of those — so change is finite without space being pixelated.
NUMBER: any completable process has finitely many costly steps.
QUOTE: "Gliding through a continuum of non-orthogonal (overlapping) states is free; only transitions to orthogonal (distinguishable) states cost, and an infinite chain of such steps, each costing \(\ge\) a fixed floor, cannot complete under finite resource"
SOURCE: https://physics.magflowmeters.com/granularity/
STATUS: DERIVED (link 1 of the reduction chain), conditional on the cost-floor posit.

## SHAPE-LOAD-BEARING

### Exactly three families of matter — a topological integer computed two independent ways
PLAIN: Why nature repeats its particles in exactly three families is a bare unexplained "3" in the Standard Model; here it is a topological index of the 13-D shape — an integer no smooth deformation can change — computed by two independent mathematical routes that both return three left-handed families and zero mirrors.
NUMBER: χ(K₆,E) = −3; boundary index (n_L, n_R) = (+3, 0); two routes (Atiyah–Patodi–Singer and Borel–Weil–Bott) agree.
QUOTE: "The Atiyah–Patodi–Singer (APS) index on the orbifold interval θ∈[0,π] ... gives (n_L,n_R)=(+3,0): three net left-handed chiral zero modes, zero right-handed. The Borel–Weil–Bott (BWB) scan over admissible line bundles on K_6=SU(3)/T^2 gives |index|=3."
SOURCE: https://physics.magflowmeters.com/gates/dossiers/uqf7.html, sg3.html, deeproot-shape.html; Fable_GUT_merged parts 7, 14, 20; TOE_FINAL_merged part 1/4; https://physics.magflowmeters.com/gates/ (SG-3)
STATUS: DERIVED-GIVEN-anchor · RESOLVED +0 — honestly "given E" (the observed matter content is a measured anchor); the corpus explicitly bars upgrading to "geometry forces 3 families from nothing."

### Universes with 2, 4, or 5 families are geometrically impossible on this shape
PLAIN: A value-blind enumeration proved the shape can only produce family counts from a fixed list of integers — and 2, 4, and 5 are simply not on the list, so ruling out a fourth family no longer rests on collider data at all (which nonetheless agrees: 2.984 ± 0.008 light neutrino species, where a light fourth family would be off by ~125σ).
NUMBER: attainable index values = {0} ∪ SU(3) irrep dimensions {0,1,3,6,8,10,15,...}; two computational routes agree on 81/81 and 289/289 test weights in exact arithmetic.
QUOTE: "Because 2 and 4 never appear as SU(3) irrep dimensions, the exclusion of a two-family or a four-family world is geometrically forced and target-blind — it no longer rests on the measured LEP bound at all."
SOURCE: https://physics.magflowmeters.com/gates/dossiers/sg3.html and uqf7.html; https://physics.magflowmeters.com/walls/
STATUS: geometry-forced, target-blind sharpening within DERIVED-GIVEN-anchor · RESOLVED +0; the LEP pull is reported exactly as 2.000σ, "a mild, non-decisive consistency."

### Folding a circle deletes the mirror world — and the unfolded control case proves it
PLAIN: On an unfolded extra-dimensional circle every particle would come with a mirror-image twin nobody has ever seen; folding the circle in half deletes exactly the mirror copies — the index goes from (+3,+3) to (+3,0) — and the corpus keeps the bare-circle failure as the proof that the fold is load-bearing physics, not decoration.
NUMBER: bare circle (control): (n_L,n_R) = (+3,+3); folded: (+3, 0); mirror fermions independently excluded by the measured LEP Z-width.
QUOTE: "a bare, un-orbifolded S¹_Y, which is handedness-neutral and mirrors every fermion, returning the negative-control index (n_L,n_R)=(+3,+3) — this bare-circle control is the proof that the orbifold fold is load-bearing physics, not a decorative add-on"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/sg3.html, uqf7.html, gap11.html; Fable_GUT_merged parts 16–17, 28
STATUS: DERIVED-GIVEN-anchor · RESOLVED +0 (hand-checkable index computation plus measured exclusion of mirrors).

### Proton decay is an exact algebraic zero — checked across 12,391 operators and 13,467 tower modes
PLAIN: Every unification scheme since 1974 fights proton decay by making dangerous particles heavy; here the geometry gives quarks and leptons no connecting mediator at all, so every proton-decay coefficient is exactly zero at every operator size — a machine census of 12,391 candidate operators found zero escapees, and a scan of 13,467 higher excitation modes found zero hidden proton-killers.
NUMBER: Π_q M Π_ℓ = 0 identically; 12,391 operators at dimension ≤ 20, 0 escapees; 13,467 + 540 KK modes, 0 leptoquark candidates, 0 fails in 2009 selection-rule checks.
QUOTE: "the frozen geometry does not merely make proton decay rare — it removes the algebraic room for a baryon-number-violating four-fermion operator to be written down with a nonzero coefficient, order by order, with no dimension left unchecked"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/sg9.html; Fable_GUT_merged parts 5, 10, 13, 18, 23, 27; https://physics.magflowmeters.com/gates/ (SG-9)
STATUS: DERIVED-GIVEN-anchor · RESOLVED +0 at the operator level; the numerical lifetime is kept separate as Diagnostic only, and non-perturbative effects are disclosed as out of scope.

### A dark-matter particle nobody put in by hand
PLAIN: The same frozen shape fixed to produce the Standard Model also contains, on its boundary, a neutral particle structurally forbidden from decaying — selected 17 of 18 times across independent reweightings frozen before any comparison to the measured dark-matter abundance, with exactly one allowed way to talk to ordinary matter.
NUMBER: 17/18 structural-selection picks across 5 reweightings; unique renormalizable Higgs portal |H|²χ²; Ω_DM h² ≈ 0.12 used only as a comparison target, never fitted.
QUOTE: "also localizes, on its own orbifold boundary, a single electrically- and color-neutral state that is structurally forbidden from decaying — a dark-matter candidate that nobody had to add by hand"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/gap11.html; https://physics.magflowmeters.com/gates/ (Gap-11); TOE_FINAL_merged part 2/4
STATUS: CERTIFIED-IRREDUCIBLE · RESOLVED +0 (anchor-limited): identity and stability are geometric outputs; the relic abundance is explicitly NOT derived — the one remaining overlap integral is named and left unrun.

### One survivor from a candidate space bigger than 10¹⁴ — by a mechanical funnel, not taste
PLAIN: Rather than scanning 10¹⁴-plus candidate geometries, the Standard Model's own structural facts were used as hard pass/fail filters — spheres, tori, Calabi–Yau spaces, and Witten's 1981 candidate each die on a named constraint (mirror particles killed by LEP data, proton lifetimes killed by Super-Kamiokande) — and exactly one branch survives.
NUMBER: >10¹⁴ phenomenologically distinct compactifications in the catalog; 1 surviving branch; elimination funnel keyed to the ten construction gates (Gates 1–10), with per-candidate datasheets in Appendix GS.
QUOTE: "no stage involves taste. Every elimination names a constraint ... the search feels mechanical because it is" and "The selector therefore returns one surviving branch under the declared search category, not a continuous family."
SOURCE: Fable_GUT_merged parts 2–4, 7, 12, 28
STATUS: uniqueness claimed only inside the declared search category (the corpus's own repeated qualifier); every verdict carries a pointer to its elimination record, offered as an attack surface.

### The one cheaper rival shape was built end-to-end — and it breaks
PLAIN: The single geometric competitor cheaper than the chosen color shape (CP², two dimensions smaller) was constructed in full and fails at the gauge-recovery test by over-producing force carriers — and where it does work, its family count is a tunable dial rather than a forced integer, so the selector paid two extra dimensions for unfakeability.
NUMBER: CP² = SU(3)/U(2) eliminated; K₆ retained with forced index −3.
QUOTE: "the cheaper-looking rival $CP^2=SU(3)/U(2)$ was built end-to-end and breaks at the gauge gate, so it is not actually cheaper once forced to reproduce the target. That is the cleanest real elimination in the program." and "The selector pays two extra dimensions for forcedness"
SOURCE: https://physics.magflowmeters.com/shape/; https://physics.magflowmeters.com/anchors/; Fable_GUT_merged parts 3, 7; https://physics.magflowmeters.com/gates/dossiers/sg2.html
STATUS: derived over the enumerated shelf; whole-shelf completeness open; minimality is category-relative.

### Remove any piece of the shape and named predictions die
PLAIN: A formal removal audit shows nothing in the 13-D shape is decoration — delete the 6-D color factor and the strong force loses its origin and "three generations" becomes a free number again; delete the sphere and the W bosons lose their source; delete the fold and mirror matter returns; and a theorem shows no proper subset of the three layers (stage, rulebook, actors) can pass all ten construction gates.
NUMBER: 10 named terms, each with a first-failed gate; 12 stripped-down candidate classes exhausted, every proper subset fails.
QUOTE: "Every named term has a first-failed-gate. No term is ornamental." and "Theorem (Three-Layer Necessity). Inside the declared search category ... no proper subset of \(\{\times, \oplus, \otimes\}\) can instantiate all required Gates 1–10 simultaneously."
SOURCE: Fable_GUT_merged parts 11–13, 15, 17, 24; https://physics.magflowmeters.com/shape/
STATUS: certificate-complete null-space audit — explicitly category-relative, not a universal no-go; 9 named reviewer falsification challenges published, none met.

### The force-carrier pieces are forced by theorems, not picked
PLAIN: The weak force cannot live on a donut — a hand-checkable theorem says no torus of any dimension carries a non-abelian symmetry, so the sphere is forced; a bare circle would predict mirror particles that collider data exclude, forcing the fold; and the color factor is the unique clean choice among the complete 7-class list of candidates.
NUMBER: 7 candidate subgroup classes, 1 survivor (K₆ = SU(3)/T²).
QUOTE: "The weak sector must live on S² because no torus or abelian factor of any dimension carries a non-abelian SU(2) isometry"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/sg1.html, sg2.html, deeproot-shape.html; https://physics.magflowmeters.com/anchors/; https://physics.magflowmeters.com/shape/
STATUS: whole-shelf forced for the sphere and fold (shelf-closing theorems); K₆ derived over the enumerated shelf — the 13-D carrier as a whole is SELECTED BY CONSTRAINTS, REDUCED-TO-AXIOM · ANCHORED +1, explicitly not a uniqueness proof.

### Eleven rival shapes named, ten scored — and the corpus cut its own winning margin from 18× to 4×
PLAIN: Eleven named rival geometries spanning 4 to 12 dimensions were run against 13-D under a cost metric declared before scoring — one fails to generate the target at all, and the ten actually scored all lose — and when a self-audit found the advertised 18× advantage overcounted, the corpus published the smaller number.
NUMBER: 0 REFUTED · 1 FAILS-TO-GENERATE · 10 LOSE; honest margin ≈ 4× (corrected from ~18×); honest input count ≈ 13–14 charged reals.
QUOTE: "the corrected, honestly-charged margin is the more modest but defensible ~4×. A smaller, true number beats a larger, unsupportable one, and this document reports the smaller one."
SOURCE: https://physics.magflowmeters.com/gates/dossiers/deeproot-shape.html
STATUS: DERIVED-SURVEY (first-pass, not exhaustive); the shape gate overall is REDUCED-TO-AXIOM · ANCHORED +1 — selected by constraints, not forced.

### The infinite tower of extra-dimensional particles adds up to one exact fraction — a lever generic string spaces don't have
PLAIN: Compactification creates an infinite ladder of heavy particles whose combined quantum effect is usually uncontrollable; here the shape's six-element symmetry forces the whole infinite sum to collapse to exact closed-form rationals, checked by two independent methods to ten decimal places — and the corpus states that generic Calabi–Yau spaces structurally cannot deliver this.
NUMBER: ζ_K6(−1) = −8033/100800 (two independent routes agree to ~4–6×10⁻¹¹); Str[C₂] = −4 exactly.
QUOTE: "the infinite Kaluza–Klein tower ... is shown, exactly and without a single free or fitted parameter, to organize itself into a finite, closed-form, regularization-independent object" and "A generic Calabi–Yau or G₂ space simply does not have this lever available."
SOURCE: https://physics.magflowmeters.com/gates/dossiers/uqf10.html
STATUS: DERIVED-GIVEN-anchor · RESOLVED +0; a tree-level moduli-stability saddle is carried openly as a named residual alongside.

### The extra dimensions were computed not to collapse — clearing the bound 35× at weakest
PLAIN: The classic killer of extra-dimension theories — the hidden dimensions crumpling or blowing up under quantum corrections — was computed against a pre-attached numerical bound and cleared it by 35× in the weakest accepted variant (about 2,400× centrally), with a later self-caught sign correction making the stability well deeper, not shallower, and no runaway (tachyonic) mode possible at linear order.
NUMBER: bound cleared 35× (weakest) / 2.4×10³ (central); boundary coefficient c_bdry = −1.08×10⁻² negative across the full band; 0 negative-mass-squared modes at linearized level; 1 dynamical modulus vs "thousands" in the string-landscape baseline.
QUOTE: "v10 the boundary-sign event \(c_{bdry}=-1.08\times10^{-2}\) (negative across the full band) ⟹ the stabilization well exists unconditionally in \(c_{loop}\)"
SOURCE: Fable_Quantum_merged parts 1, 9; TOE_FINAL_merged part 2/4
STATUS: closed at decision grade in the corpus (explicitly not certificate grade); the paper's own independent verification gate stays AUDIT; global shrinking-volume question named OPEN.

### Being 13-dimensional kills whole classes of quantum diseases — and that's a theorem about odd numbers
PLAIN: The fatal anomalies that quietly kill most unification attempts can only mathematically exist in certain dimensions, and 13, being odd, is not one of them — the corpus proves the would-be one-loop test literally has no well-defined target at odd dimension (verified by re-running at 12 and 14, where it is well-posed), so the dimension count is doing real work.
NUMBER: at D = 13 the would-be anomaly pole sits at s = 7/2 (a half-integer — no pole); 10 of 16 anomaly classes close at certificate tier in Paper 3.
QUOTE: "the object the test would need to interrogate does not exist as a scheme-independent quantity at odd D"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/uqf5a-5b.html; Fable_Quantum_merged parts 4, 13
STATUS: DISSOLVED-GIVEN-root (dimension parity) inside CERTIFIED-IRREDUCIBLE · RESOLVED +0; Paper 3's own anomaly gate honestly sits at AUDIT with a named roadmap for boundary classes.

### The keystone finiteness coefficient computed from pure geometry — zero measured inputs
PLAIN: The single hard number that tests whether the 13-D shape survives as a finite quantum theory at one loop was computed as an exact fraction with no measured constant anywhere in it — after the same machinery reproduced four textbook sphere values to fourteen decimal places.
NUMBER: a₆/a₀|_K₆ = −6373/630 exactly; sphere calibrations a₆(S²)=4/315, a₆(S⁴)=74/63, a₆(S⁶)=1139/63 reproduced to ~10⁻¹⁴.
QUOTE: "The whole computation rests on no measured, real-world number at all — only on the shape of the geometry."
SOURCE: https://physics.magflowmeters.com/gates/dossiers/gap01.html; https://physics.magflowmeters.com/gates/ (Gap-01)
STATUS: DERIVED-GIVEN-anchor · RESOLVED +0 (given the operator content); explicitly not a UV-completeness proof.

### Why the Higgs is a doublet: a decades-old classification theorem, not a postulate
PLAIN: The Standard Model postulates the symmetry-breaking field is a single doublet because that happens to work; here it is forced by the external Wu–Yang/Dray classification of monopole fields on the two-sphere — the lowest mode of the charge-1 bundle is a doublet, full stop.
NUMBER: exactly one doublet, winding number n_H = 1.
QUOTE: "Electroweak symmetry breaking by exactly one doublet is asserted to be forced by the Wu–Yang/Dray classification of sections of charge-N monopole line bundles on S² ... not a postulated doublet chosen to match observation"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/sg5.html
STATUS: DERIVED-GIVEN-E within a CLOSED / DERIVED-GIVEN-anchor · RESOLVED +0 gate.

### Where the vacuum rests is forced by symmetry, not tuned
PLAIN: In string-style constructions the resting point of the internal geometry is one choice among ~10⁵⁰⁰; here the shape's exact six-element permutation symmetry forces the resting point to the symmetric center by group theory alone — any symmetric potential has a critical point there, no tuning available.
NUMBER: resting point ū = (1,1,1) forced by the order-6 Weyl group S₃; supporting exact value ζ_K6(−1) = −8033/100800 confirmed to ~22 digits.
QUOTE: "The chamber-center point ū=(1,1,1) is therefore automatically a critical point — ∇V=0 there — of any S₃-invariant potential V, for purely group-theoretic reasons, with no potential shape tuned to land on that answer."
SOURCE: https://physics.magflowmeters.com/gates/dossiers/sg6.html
STATUS: criticality DERIVED-GIVEN-E (gate DERIVED-GIVEN-anchor · RESOLVED +0); minimum-vs-saddle rests on one remaining sign the corpus proves the shape alone cannot fix — carried as an open, measurement-payable bet.

### Everything still missing about black-hole entropy reduces to ONE object nobody has ever computed
PLAIN: The unfinished part of the black-hole entropy problem is proved to collapse onto a single named mathematical coefficient on the shape's folded circle — a quantity the mathematics literature has never computed for anyone, in any theory, so the remaining wall stands in front of the whole field.
NUMBER: boundary heat-kernel expansion known exactly only through order a₅; the needed a₆ certified absent from the literature.
QUOTE: "the general boundary heat-kernel expansion for mixed Neumann/Dirichlet conditions is known, exactly, only through a₅ (Branson–Gilkey–Kirsten–Vassilevich); a₆ on this class of boundary has never been computed by anyone, for any application"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/gap13.html
STATUS: CERTIFIED-IRREDUCIBLE · RESOLVED +0 — the proof of irreducibility is the deliverable; microstate count and Page mechanism explicitly not claimed.

## ELEGANCE

### A 113-orders-of-magnitude miss, kept on the books on purpose
PLAIN: The framework attacked the dark-energy value with its own finiteness machinery, missed by 113 orders of magnitude, and keeps the failure published as proof its tests can actually fail — and as proof the geometry was never reverse-engineered to fit, since the frozen geometry produces no dark-energy quantity of any kind to tune. A 2026-07-07 audit strengthened the closure further: the leftover demand to derive the value from a literal single-point Big Bang dissolves as a wrong-target obligation — an exact singular origin is neither a measured finite record nor part of the frozen shape, and four different unobserved origin-completions all agree on every finite late-time record. The measured value stays; only the imported demand dissolves.
NUMBER: miss of 113.75 orders of magnitude, cross-checked two ways; Λ ≈ (2.3 meV)⁴ ≈ 10⁻¹²² M_Pl⁴ kept as the fifth measured input.
QUOTE: "a granularity/cost-floor attack on the value was run and missed by 113.75 orders of magnitude, a genuine tripped negative control, not a shrug" and "produces no Λ term of any kind — not a small one, not a mistuned one, none."
SOURCE: https://physics.magflowmeters.com/gates/dossiers/gap05-value.html and deeproot-granularity.html; https://physics.magflowmeters.com/gates/ (Gap-05)
STATUS: MEASURED-ANCHOR · RESOLVED +0 — honestly measured, explicitly never predicted; the miss bars ever claiming granularity explains the value.

### The theory tested its deepest hope on the hardest number in physics — and published the failure at full strength
PLAIN: On the cosmological constant — where a curve-fitter would have found a way to claim a win — the framework computed its own best cancellation mechanism, watched it fail at every order, proved by a clean group-theory argument why it had to fail, and published both certificates, never comparing to the observed value anywhere.
NUMBER: cancellation ratio 0.58 at k=0 and 1.000 at k=1–8 (a real cancellation would give 0); the ~122-order burden left standing.
QUOTE: "the exact-weight graded supertrace RAN and CLOSED as honest FAIL — no structural cancellation at any coefficient order ... the chamber route to Λ is closed, Weinberg stands"
SOURCE: Fable_Quantum_merged part 1/13; TOE_FINAL_merged parts 1–2; https://physics.magflowmeters.com/gates/dossiers/gap05-stability.html; https://physics.magflowmeters.com/toe/
STATUS: computed honest-FAIL, banked; the stability obstruction itself is CERTIFIED-IRREDUCIBLE · RESOLVED +0; Λ stays Weinberg-open.

### The consistency check you can do on a napkin — and it does double duty
PLAIN: The theory's charge bookkeeping hangs on arithmetic anyone can verify in 30 seconds — 3·(1/6) − 1/2 = 0 — and shifting one hypercharge by a single lattice step breaks two independent things at once (the electron's charge comes out −5/6 AND the anomaly sum stops vanishing), so the assignment has no slack at all.
NUMBER: 3·(1/6) − 1/2 = 0; wrong step ⇒ electron Q = −5/6 and a nonzero anomaly sum, simultaneously.
QUOTE: "Two things fail at once: the charge table gives the electron \(Q = -5/6\), and the napkin witness breaks... The same number that fixes the charges fixes the quantum consistency: that double duty is why the hypercharge lattice has no slack"
SOURCE: Fable_Forces_merged parts 1, 3; Fable_GUT_merged part 1; https://physics.magflowmeters.com/forces/; TOE_FINAL_merged part 1/4
STATUS: live hand-checkable witness; the cancellation is "inherited, not arranged" — consistency, not sole-origin proof.

### The program publishes its own refutations, retractions, and downgrades
PLAIN: Four of its own optimistic claims were falsified by its own audit and published as refuted with reasons; two tempting numerical coincidences were checked and retired as "an O(1) coincidence is not evidence"; a promising matter-antimatter result was withdrawn the same day it was produced; the quantum-computer side logged seven-plus self-caught corrections including retiring its flashiest ratios; and the headline input-economy claim was cut from ~4× to an honest 1.8× when a self-audit found overcounting.
NUMBER: 4 self-refuted routes; 2 retired coincidences; same-day withdrawal (R = 1.0001, 2026-06-04); ≥7 engineering corrections; margin 18×→4×; economy ~4×→1.8× (≈13–14 charged reals vs ≈25).
QUOTE: "Doing the physics this round actively falsified these optimistic closures. Re-attempting them as written wastes effort; the honest residual (where one remains) is named." and "Not '4 inputs → 22 outputs.' That historical headline is known-overstated and explicitly retired here."
SOURCE: https://physics.magflowmeters.com/residuals/; https://physics.magflowmeters.com/gates/dossiers/gap02.html, sg1.html, deeproot-shape.html; Fable_Quantum_merged parts 12–13
STATUS: banked negatives and corrected accountings, displayed by the corpus as its own discipline record.

### The honesty ledger: every claim graded, every anchor named, nothing claimed from nothing
PLAIN: The theory is graded as 33 distinct claims with the anchors named on each — the gates page shows 26 resting on the existing floor and 7 costing exactly one named value-free assumption each, zero vague — and states plainly that no gate is "solved from nothing," while the front page keeps the residual tensions in plain view rather than folding them into the wins.
NUMBER: 33 gates: 26 at +0, 7 at +1 (one named axiom each), 0 open (gates page); the home page presents the same board as "30 resolved at a terminal endpoint, 1 certified standing falsifier, and 2 honestly open at the structural frontier."
QUOTE: "26 closed at +0... 7 closed at +1 (each at the price of one named, value-free axiom) · 0 open... No gate is 'solved from nothing.' Every result ultimately rests on a small set of measured numbers"
SOURCE: https://physics.magflowmeters.com/gates/; https://physics.magflowmeters.com/; https://physics.magflowmeters.com/walls/
STATUS: the corpus's own reconciled boards at different audit dates; "anchored ≠ closed, selected is not forced, dissolved is not solved" — its own words.

### The whole framework leans on five "just-is" numbers — and says any theory's floor is at least one
PLAIN: Everything consumed from experiment at the anchor level is five numbers (Planck mass, gauge couplings, top coupling, one mixing element, dark-energy density) where standard particle physics leaves dozens of dials free — and the corpus publishes the fuller honest table too (~12–14 total measured inputs, each with a named consumer), stating as a rule that no framework anywhere derives its inputs from nothing.
NUMBER: 5 anchor inputs; ~12–14 total measured inputs with named consumers; input floor ≥ 1 for any theory.
QUOTE: "This value takes its place as the fifth of exactly five numbers the present framework accepts as 'just is'" and "no framework derives its measured inputs from nothing. The floor of measured inputs is never zero — not here, not anywhere."
SOURCE: https://physics.magflowmeters.com/gates/dossiers/gap05-value.html; https://physics.magflowmeters.com/anchors/
STATUS: anchors, not derived outputs; the anchors table is offered as accounting — "It closes nothing ... It derives nothing."

### The weakest link is printed on the cover, not buried
PLAIN: The quantum paper grades itself by the strictest possible rule — the whole work is only as strong as the weakest of its seventeen gates — prints that grade (AUDIT) on the front page, machine-enforces that no sentence claims more, and deliberately left its single most tempting row (strong CP) open rather than "completing" it.
NUMBER: Σ = min over 17 gates = AUDIT; 8 gates honestly held open.
QUOTE: "seventeen gates, each read in two tenses — what is closed, and what would close it — with the weakest link printed on the cover, not buried. The front page says the only number the min-rule permits: Σ = AUDIT"
SOURCE: Fable_Quantum_merged parts 1, 13
STATUS: self-declared aggregate, machine-checked.

### Freeze-before-compare: the anti-fitting rule is mechanical, not rhetorical — with a registered test built to come out negative
PLAIN: Every object the comparison pipeline reads is locked and hash-stamped before any measured number is loaded, any rule must be writable without ever looking at the answer it predicts, a published knob-audit table invites reviewers to find one unlisted parameter (finding one triggers an automatic downgrade), and a blind control was registered in advance to come out negative so a reader can check the grading discipline actually rejects things.
NUMBER: 18 frozen object classes; 10-row knob audit; registered blind-negative control PCM-12.
QUOTE: "Target-blindness — show the rule can be written without using the target observable. A rule that quotes the answer it is supposed to predict is target-selected, not forced." and "the closed core, with the registered blind-negative control PCM-12 built to come out negative so the discipline is checkable"
SOURCE: https://physics.magflowmeters.com/shape/; Fable_GUT_merged parts 4, 26; https://physics.magflowmeters.com/toe/
STATUS: binding rulebook; violation formally voids the certificate.

### One sentence predicts the theory's wins AND its own near-misses — and the one testable exception was tested
PLAIN: "Topology is rigid; magnitudes flow" cleanly predicts which numbers the geometry pins (integer counts, symmetries, dimensions) and which stay measured (masses, couplings) — and when the one continuous constant with a plausible derivation mechanism (the top coupling via a renormalization attractor) was computed target-blind, it came out wrong (1.34 vs 0.9665) and the framework reports the miss openly, keeping y_t a measured anchor.
NUMBER: attractor y_t ≈ 1.34 vs measured 0.9665 — negative result published.
QUOTE: "We ran the computation — and it does not reduce \(y_t\). At one loop, the infrared attractor sits near \(y_t \approx 1.34\), while the measured value is \(0.9665\)... (Checked target-blind, and independently reproduced.)"
SOURCE: https://physics.magflowmeters.com/process/what-geometry-forces.html
STATUS: honestly reported negative; the pattern is stated as falsifiable in both directions.

### The hierarchy "problem" is a ratio of two rulers, not a third mystery
PLAIN: The famous 17-orders-of-magnitude gap between the weak scale and the Planck scale stops being a mystery once both scales are honestly booked as measured inputs — the gap is just their quotient, and there was never a third object owing anyone a derivation.
NUMBER: H = v_EW/M_Pl ≈ 2×10⁻¹⁷ (from M_Pl = 1.2209×10¹⁹ GeV, v_EW ≈ 246 GeV).
QUOTE: "the hierarchy \(H \equiv v_{\rm EW}/M_{\rm Pl} \approx 2\times10^{-17}\) ... is arithmetic — the quotient of two numbers already charged to the ledger. It is emphatically not a third quantity owed a derivation of its own."
SOURCE: https://physics.magflowmeters.com/gates/dossiers/deeproot-scale.html; https://physics.magflowmeters.com/gates/ (DeepRoot-Scale)
STATUS: MEASURED-ANCHOR · RESOLVED +0; the electroweak scale's microphysical origin stays a named open hole.

### Why atoms are exactly neutral is an identity, not a coincidence
PLAIN: Because electromagnetism is forced to be the leftover of the weak sector rather than an independent force, the photon's charges are the weak sector's charges by construction — the perfect cancellation that makes atoms neutral (to one part in 10²¹) is inherited, not tuned.
NUMBER: Q = T₃ + Y reproduces every observed charge row; matter neutrality exact to ~10⁻²¹.
QUOTE: "atom neutrality would become a coincidence to be tuned rather than an identity to be inherited. The composite structure makes that failure unwritable: QED's charges are the weak sector's charges, by construction"
SOURCE: Fable_Forces_merged part 3/4; Fable_GUT_merged part 4
STATUS: interface claim, machine-checked (certificate Q04 PASS).

### Matter vs antimatter: a wall proven, not an excuse offered
PLAIN: Rather than tuning unobservable heavy-neutrino parameters to "explain" the matter excess (as the literature does), the framework proved by two independent exact calculations that the one missing number cannot be extracted from anything ever measured — and named the future measurement that would supply it.
NUMBER: two independent routes agree to residual ≤ 7.1×10⁻¹⁶ across six decades of the heavy scale; η_B ≈ 6.1×10⁻¹⁰ consumed as a measured input.
QUOTE: "proven un-derivable from the four anchors and un-measurable from the entire light-neutrino sector, by two independent, target-blind calculational routes that reach exact agreement"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/gap10-bg10.html
STATUS: CERTIFIED-IRREDUCIBLE · RESOLVED +0 — a proof of a wall; no η_B value claimed.

### Why a dark-energy term must exist at all is a theorem — three tangled questions cleanly split
PLAIN: What looks like one baffling dark-energy mystery splits into three questions with three different clean answers: a Λ-slot must exist (forced by Lovelock's 1971 classification theorem in 4D), its tiny size is a measurement, and the scary vacuum estimate never gravitates (dissolved) — the three are never conflated.
NUMBER: Λ = (2.3 meV)⁴ ≈ 10⁻¹²² M_Pl⁴, charged as a measured input.
QUOTE: "the existence of a cosmological-constant term is forced by a complete classification theorem (Lovelock, 1971) ... so 'why is there a \(\Lambda\) slot at all' is closed, even while 'why does \(\Lambda\) have the value it has' is not"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/deeproot-scale.html and lambda-catastrophe.html
STATUS: existence forced (known theorem) / value MEASURED / catastrophe dissolved — as stated per question.

### An absolute scale must exist — that part is a theorem; its value is read, not derived
PLAIN: The framework proves some absolute measurement ruler must exist (change units and any bare number changes with them, so only ratios or anchored values carry content), then honestly reads the ruler's value from experiment instead of pretending to derive it.
NUMBER: M_Pl = 1.2209×10¹⁹ GeV (measured anchor).
QUOTE: "That an absolute scale must exist is a theorem ... But the value of that anchor is read from experiment, never derived. ... Existence is proven; the numbers are measured; the two are never merged."
SOURCE: https://physics.magflowmeters.com/building-blocks/
STATUS: existence proven; value anchored to measurement.

### Every hard quantum-gravity consistency check funnels to one named problem
PLAIN: Rather than hand-waving its hardest quantum checks, the theory proves that its graviton sector, UV completion, short-distance structure, and causality requirements all reduce to one single shared mathematical fact — the Yang–Mills mass gap — naming exactly the one thing the program leans on instead of hiding many loose ends.
NUMBER: 4+ consistency gates reduced to 1 shared object.
QUOTE: "it proves that every one of its own consistency requirements reduces to that single shared object (Gap-02), and that the object's value enters as a measured anchor. That is an honest, closed terminal"
SOURCE: https://physics.magflowmeters.com/quantum/
STATUS: CERTIFIED-IRREDUCIBLE (the Yang–Mills problem itself is not claimed solved; its value enters as a measured anchor).

### The same two frozen numbers run particle physics AND the chip design
PLAIN: The integer 3 that counts the particle families and a spectral gap of 0.260 — both frozen in the geometry for physics reasons — turn up doing a second, completely unrelated job inside the quantum-computer design, with no feedback loop between the two projects.
NUMBER: Atiyah–Singer index = 3; spectral gap Δ ≈ 0.260.
QUOTE: "the same frozen geometric invariants — the Atiyah–Singer index equal to 3 (the same integer that counts three particle families) and a spectral gap Δ ≈ 0.260 — show up doing a second, unrelated job"
SOURCE: https://physics.magflowmeters.com/tests/quantum-computer.html
STATUS: structural invariants carried through both projects; the QC result itself is simulated/design-stage.

### Proton safety without banning what the Standard Model needs
PLAIN: The lazy fix — postulating a law that baryon number is conserved — would secretly outlaw processes the Standard Model itself requires (sphalerons); the geometric mechanism forbids proton decay while leaving those processes untouched.
NUMBER: sphalerons change B and L by ±3 each; a global U(1)_B symmetry is excluded for exactly this reason.
QUOTE: "A continuous global \(U(1)_B\) symmetry would forbid sphalerons. So global \(B\) symmetry is structurally incompatible with the SM."
SOURCE: Fable_GUT_merged part 23
STATUS: named constraint inside the proton-safety closure (Claimed certificate pass at operator level).

### One mechanical rule sorts every cosmic object the way physicists do case-by-case
PLAIN: A single four-part test — coupled, encoded, stabilized, retrievable — applied blindly to nine early-universe objects sorts every one exactly the way decades of case-by-case physics judgment does (CMB photons real, monopoles not, dark matter's identity open), with zero mismatches.
NUMBER: 9/9 objects, 0 mismatches.
QUOTE: "One is case-by-case textbook judgment, the other is a single mechanical rule applied blindly — they share no logic, yet they sort every object the same way."
SOURCE: https://physics.magflowmeters.com/early-universe/tests/
STATUS: Agrees (corpus label).

### The knowable universe is a window, not a wall — and both methods stop at the same Planck instant
PLAIN: Two structural consequences fall out for free: the knowable beginning and end are always the same distance in time from us (the observable universe widens symmetrically, no edge is ever hit), and dimensional analysis and record-cost bookkeeping — two unrelated arguments — both run out at the identical instant, 5.39×10⁻⁴⁴ seconds, where recordable history begins.
NUMBER: t_Pl ≈ 5.39×10⁻⁴⁴ s (both methods).
QUOTE: "the knowable beginning and the knowable end are always the same distance in time from us" and "Dimensional analysis and record-cost bookkeeping share no machinery, yet both stop at the identical wall — an honest shared limit, not a computed win."
SOURCE: https://physics.magflowmeters.com/early-universe/ and /early-universe/tests/
STATUS: derived structural consequence + an honestly-labeled shared limit ("not a computed win").

### "Forever" was never available: the eternal horizon retired, the real one kept
PLAIN: The textbook event horizon needs an infinite future to even be defined, but real black holes evaporate — so the framework keeps only the locally defined trapping horizon, which stays strictly one-way for the object's entire lifetime, effectively absolute for any observer in a 10-billion-year-old universe.
NUMBER: one-way for ~10⁶⁷ yr (stellar) to ~10¹⁰⁰ yr (supermassive) vs a universe ~10¹⁰ yr old.
QUOTE: "with a singularity-free interior there is, in Hawking's own 2014 phrase, 'no event horizon, only an apparent horizon.' The trapping horizon is not thereby made leaky — it is one-way for the entire \(10^{67}\)–\(10^{100}\)-year lifetime"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/blackhole-singularity.html
STATUS: part of the DISSOLVED-GIVEN-root closure; consistent with the GW150914 area-law confirmation.

### The information-escape turnover inside an evaporating black hole solves in closed form
PLAIN: Where the state of the art needs holography or two-dimensional toy models, this geometry's quantum-extremal-surface location solves explicitly and symbolically, and the information-recovery turnover comes out structural rather than assumed.
NUMBER: island location x⋆ = −r_h/2 + √(3Gc+9παr_h²)/(6√(πα)).
QUOTE: "the QES (quantum extremal surface) location itself solves explicitly and symbolically on the frozen 4D s-wave-reduced sector ... and the qualitative turnover survives without needing to postulate a finite-dimensional horizon Hilbert space by hand"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/gap13.html
STATUS: derived (qualitative turnover); the Page-time magnitude remains open and scheme-dependent — as it is for the whole field, per the corpus.

### The universe's smallest meaningful scale belongs to the strong force, not gravity
PLAIN: In this geometry the fundamental resolution scale is not the Planck length of gravity folklore — it is a pure color-force object about 194 Planck lengths across, a concrete, surprising read-off of where the shape actually bottoms out.
NUMBER: R₀/ℓ_Planck ~ 194 (a pure color/gauge object with zero gravitational input).
QUOTE: "the minimal-length scale here is a pure-color object (~194 Planck lengths)"
SOURCE: https://physics.magflowmeters.com/gates/dossiers/uqf5c.html
STATUS: banked screening result; whether gravity owns its own intrinsic minimal scale is isolated and still open.

### No hidden free-rider particles: spectator sectors are ruled out by constraint alone
PLAIN: Extra disconnected particle sectors that couple to nothing — the free-riders that plague model-building elsewhere — are eliminated outright by the nonseparability constraint itself, which the corpus calls the strongest, rarest kind of result: forced by the constraints, not merely consistent with them.
NUMBER: —
QUOTE: "Unpaid spectator sectors and disconnected vectorlike additions to the observed spectrum are ruled out by the Nonseparability constraint itself, not by a modeling choice — the strongest, rarest kind of result, forced rather than merely consistent."
SOURCE: https://physics.magflowmeters.com/emergent-separability/
STATUS: resolved (with the three-generation count explicitly kept separate as observation-earned).

### The report card built the theory
PLAIN: The eight classic ways a grand unified theory dies (mirror particles, anomalies, proton decay, unprotected Higgs, arbitrary flavor...) were not used to grade a finished theory — the same failure list was the blueprint that eliminated candidate geometries in the first place, one standard applied in two tenses.
NUMBER: 10 required construction gates; every proper subset of the three layers provably fails at least one.
QUOTE: "Nothing was built and then graded; the grading rubric did the building."
SOURCE: Fable_GUT_merged parts 1–2 (quote in part 2, §1.3 "The Inversion")
STATUS: method claim with a four-point circularity defense (selection reads architecture, certificates read numbers; falsifiers stay live).

### The whole theory starts from a fact every physics student already knows
PLAIN: The seed of the entire framework is Gauss's law — the century-tested fact that a field outside a closed surface doesn't care how the source inside is arranged — read as a constraint the deep structure of space must reproduce exactly, which by itself eliminates whole classes of candidate geometries.
NUMBER: —
QUOTE: "a field measured outside a closed surface does not care how its source is arranged inside that surface. That is not a metaphor for the theory. It is the theory's actual starting constraint."
SOURCE: https://physics.magflowmeters.com/process/thought-experiment.html
STATUS: textbook fact plus a stated methodological choice; the page itself claims no derived number.
